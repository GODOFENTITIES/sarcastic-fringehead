"""Verification Suite for Sarcastic Fringehead (v0.1).

Covers all 6 mandatory constitutional governance, conflict resolution, RBAC quorum,
and tamper-evident audit ledger scenarios, plus tie-breaking, missing field safety,
escalation_trigger, and FastAPI gateway verification.
"""

from __future__ import annotations

from pathlib import Path
import pytest
from fastapi.testclient import TestClient

from src.audit import AuditLedger, GENESIS_HASH
from src.engine import ConstitutionalEngine
from src.governance import GovernanceManager, UnauthorizedAmendmentError
from src.main import create_app
from src.models import (
    AmendmentProposal,
    ConditionGroup,
    EvaluationRequest,
    LeafCondition,
    Rule,
    RuleScope,
)

CONSTITUTION_YAML = Path(__file__).resolve().parent.parent / "config" / "constitution.yaml"


def _build_fresh_stack():
    ledger = AuditLedger()
    engine = ConstitutionalEngine.from_yaml(CONSTITUTION_YAML, audit_ledger=ledger)
    governance = GovernanceManager(constitution=engine.constitution, audit_ledger=ledger)
    return engine, governance, ledger


def test_scenario_1_cross_tenant_privacy_block_beats_l3_allow():
    """1. Cross-Tenant Privacy Block (L0-PRIV-001):
    User usr_101 attempts to access customer_records of usr_999 while also passing
    L3-USR-001 (ALLOW preference). Assert Level 0 wins and returns BLOCK.
    """
    engine, _, _ = _build_fresh_stack()

    req = EvaluationRequest(
        request_id="req-scen1-001",
        stage="output_rail",
        jurisdiction="IN",
        session={"authenticated_user_id": "usr_101"},
        user={"preferences": {"format": "concise_json_only"}},
        tool={
            "target_resource": "customer_records",
            "args": {"target_user_id": "usr_999"},
        },
    )

    decision = engine.evaluate(req)
    assert decision.decision == "BLOCK"
    assert decision.winning_rule_id == "L0-PRIV-001"
    assert "L0-PRIV-001" in decision.matched_rule_ids
    assert "L3-USR-001" in decision.matched_rule_ids
    assert decision.violation_code == "ERR_L0_CROSS_USER_DATA_ACCESS"
    assert decision.latency_ms < 1.0


def test_scenario_2_authorized_self_access_allow():
    """2. Authorized Self-Access (ALLOW):
    User usr_101 accesses their own customer_records (target_user_id == "usr_101").
    Assert ALLOW.
    """
    engine, _, _ = _build_fresh_stack()

    req = EvaluationRequest(
        request_id="req-scen2-001",
        stage="execution_rail",
        jurisdiction="GLOBAL",
        session={"authenticated_user_id": "usr_101"},
        tool={
            "target_resource": "customer_records",
            "args": {"target_user_id": "usr_101"},
        },
    )

    decision = engine.evaluate(req)
    assert decision.decision == "ALLOW"
    assert decision.winning_rule_id is None
    assert "L0-PRIV-001" not in decision.matched_rule_ids
    assert decision.latency_ms < 1.0


def test_scenario_3_refund_threshold_escalation():
    """3. Refund Threshold Escalation (L2-ORG-001):
    Refund of $35 returns ALLOW; refund of $75 returns REVIEW routed to human_support_supervisor.
    """
    engine, _, _ = _build_fresh_stack()

    req_low = EvaluationRequest(
        request_id="req-scen3-low",
        stage="execution_rail",
        jurisdiction="GLOBAL",
        tool={"name": "issue_refund", "args": {"amount_usd": 35.00}},
    )
    dec_low = engine.evaluate(req_low)
    assert dec_low.decision == "ALLOW"
    assert dec_low.winning_rule_id is None
    assert dec_low.escalated_to is None

    req_high = EvaluationRequest(
        request_id="req-scen3-high",
        stage="execution_rail",
        jurisdiction="GLOBAL",
        tool={"name": "issue_refund", "args": {"amount_usd": 75.00}},
    )
    dec_high = engine.evaluate(req_high)
    assert dec_high.decision == "REVIEW"
    assert dec_high.winning_rule_id == "L2-ORG-001"
    assert dec_high.escalated_to == "human_support_supervisor"
    assert dec_high.violation_code == "INFO_L2_REFUND_LIMIT_EXCEEDED"


def test_scenario_4_untrusted_retrieval_quarantine():
    """4. Untrusted Retrieval Quarantine (L1-SEC-001):
    Context with contains_untrusted_retrieval: true attempting external_network_send
    without confirmation returns REVIEW routed to jev_decision_layer.
    """
    engine, _, _ = _build_fresh_stack()

    req = EvaluationRequest(
        request_id="req-scen4-001",
        stage="execution_rail",
        jurisdiction="GLOBAL",
        context={"contains_untrusted_retrieval": True},
        tool={"side_effect_class": "external_network_send"},
        session={"explicit_user_confirmation": False},
    )

    decision = engine.evaluate(req)
    assert decision.decision == "REVIEW"
    assert decision.winning_rule_id == "L1-SEC-001"
    assert decision.escalated_to == "jev_decision_layer"
    assert decision.violation_code == "WARN_L1_UNTRUSTED_TOOL_TRIGGER"


def test_scenario_5_governance_rbac_and_quorum_enforcement():
    """5. Governance RBAC & Quorum Enforcement:
    - org_administrator tries to weaken L0-PRIV-001 -> rejected (403 / UnauthorizedAmendmentError).
    - oversight_board submits an amendment to L0-PRIV-001 with only 1 signature -> rejected (quorum requires 3).
    - oversight_board submits with 3 distinct signatures -> succeeds and increments version to 1.0.1.
    """
    app = create_app(CONSTITUTION_YAML)
    client = TestClient(app)
    state = app.state.fringehead

    l0_rule = next(r for r in state.engine.constitution.rules if r.id == "L0-PRIV-001")
    modified_l0_rule = Rule(
        id="L0-PRIV-001",
        name="Cross-Tenant Personal Data Protection (Expanded Resource List)",
        level=0,
        priority_weight=100,
        owner_role="oversight_board",
        immutable_by_operator=True,
        scope=RuleScope(
            stages=["execution_rail", "output_rail"],
            jurisdictions=["GLOBAL", "IN", "EU"],
        ),
        deterministic_condition=l0_rule.deterministic_condition,
        action="BLOCK",
        violation_code="ERR_L0_CROSS_USER_DATA_ACCESS",
        audit_severity="CRITICAL",
    )

    # 5a. org_administrator tries to weaken L0-PRIV-001 -> rejected (both direct & HTTP 403)
    bad_operator_proposal = AmendmentProposal(
        proposer_role="org_administrator",
        signatures=["admin_sig_1"],
        target_rule_id="L0-PRIV-001",
        updated_rule=modified_l0_rule,
        reason="Operator attempting to modify L0 rule",
    )
    with pytest.raises(UnauthorizedAmendmentError):
        state.governance.apply_amendment(bad_operator_proposal)

    resp_op = client.post("/v1/governance/amend", json=bad_operator_proposal.model_dump())
    assert resp_op.status_code == 403

    # 5b. oversight_board submits with only 1 signature -> rejected (quorum requires 3)
    insufficient_quorum_proposal = AmendmentProposal(
        proposer_role="oversight_board",
        signatures=["board_member_1"],
        target_rule_id="L0-PRIV-001",
        updated_rule=modified_l0_rule,
        reason="Single board member amendment attempt",
    )
    with pytest.raises(UnauthorizedAmendmentError):
        state.governance.apply_amendment(insufficient_quorum_proposal)

    resp_quorum = client.post(
        "/v1/governance/amend", json=insufficient_quorum_proposal.model_dump()
    )
    assert resp_quorum.status_code == 403

    # 5c. oversight_board submits with 3 distinct signatures -> succeeds and increments version to 1.0.1
    valid_board_proposal = AmendmentProposal(
        proposer_role="oversight_board",
        signatures=["board_member_1", "board_member_2", "board_member_3"],
        target_rule_id="L0-PRIV-001",
        updated_rule=modified_l0_rule,
        reason="Approved constitutional clarification by full quorum",
    )
    resp_ok = client.post("/v1/governance/amend", json=valid_board_proposal.model_dump())
    assert resp_ok.status_code == 200
    payload = resp_ok.json()
    assert payload["new_version"] == "1.0.1"
    assert state.engine.constitution.version == "1.0.1"


def test_scenario_6_audit_ledger_tamper_detection():
    """6. Audit Ledger Tamper Detection:
    Run several evaluations, verify verify_chain() is True, mutate a historical record
    in memory, and assert verify_chain() immediately returns False at the tampered index.
    """
    engine, _, ledger = _build_fresh_stack()

    for idx in range(4):
        req = EvaluationRequest(
            request_id=f"req-audit-{idx}",
            stage="execution_rail",
            jurisdiction="GLOBAL",
            session={"authenticated_user_id": "usr_101"},
            tool={
                "target_resource": "customer_records",
                "args": {"target_user_id": "usr_101" if idx % 2 == 0 else "usr_999"},
            },
        )
        engine.evaluate(req)

    assert len(ledger.records) == 4
    assert ledger.records[0].previous_hash == GENESIS_HASH

    is_valid_before, tampered_idx_before = ledger.verify_chain()
    assert is_valid_before is True
    assert tampered_idx_before is None

    # Mutate historical record at index 1 in memory
    ledger.records[1].decision = "ALLOW"

    is_valid_after, tampered_idx_after = ledger.verify_chain()
    assert is_valid_after is False
    assert tampered_idx_after == 1


def test_escalation_trigger_conflict_tie_breakers_and_metrics():
    """Verify secondary escalation_trigger, same-level restrictiveness & priority_weight
    tie-breakers, missing field safety, and FastAPI /v1/metrics & /v1/audit/verify endpoints.
    """
    app = create_app(CONSTITUTION_YAML)
    client = TestClient(app)

    # 1. Trigger L0-SAFE-002 secondary escalation_trigger (hazard_category is 'benign', uncertainty_score is 0.42)
    req_payload = {
        "request_id": "req-esc-001",
        "stage": "input_rail",
        "jurisdiction": "GLOBAL",
        "classifier": {
            "hazard_category": "benign_ambiguous",
            "uncertainty_score": 0.42,
        },
    }
    resp = client.post("/v1/evaluate", json=req_payload)
    assert resp.status_code == 200
    data = resp.json()
    assert data["decision"] == "REVIEW"
    assert data["winning_rule_id"] == "L0-SAFE-002"
    assert data["escalated_to"] == "jev_decision_layer"

    # 2. When both L0-PRIV-001 (BLOCK, weight 100) and L0-SAFE-002 (BLOCK, weight 99) match on output_rail,
    # L0-PRIV-001 wins via higher priority_weight (100 > 99).
    both_l0_payload = {
        "request_id": "req-tie-001",
        "stage": "output_rail",
        "jurisdiction": "GLOBAL",
        "session": {"authenticated_user_id": "usr_101"},
        "tool": {
            "target_resource": "medical_history",
            "args": {"target_user_id": "usr_999"},
        },
        "classifier": {"hazard_category": "cyber_exploit"},
    }
    resp_tie = client.post("/v1/evaluate", json=both_l0_payload)
    assert resp_tie.status_code == 200
    tie_data = resp_tie.json()
    assert tie_data["decision"] == "BLOCK"
    assert tie_data["winning_rule_id"] == "L0-PRIV-001"
    assert set(tie_data["matched_rule_ids"]) == {"L0-PRIV-001", "L0-SAFE-002"}

    # 3. Verify /v1/audit/verify endpoint
    audit_resp = client.get("/v1/audit/verify")
    assert audit_resp.status_code == 200
    assert audit_resp.json()["valid"] is True
    assert audit_resp.json()["total_records"] == 2

    # 4. Verify /v1/metrics endpoint
    metrics_resp = client.get("/v1/metrics")
    assert metrics_resp.status_code == 200
    m = metrics_resp.json()
    assert m["total_requests"] == 2
    assert m["decision_counts"]["REVIEW"] == 1
    assert m["decision_counts"]["BLOCK"] == 1
    assert 0.0 < m["p50_latency_ms"] < 1.0
    assert 0.0 < m["p95_latency_ms"] < 1.0
