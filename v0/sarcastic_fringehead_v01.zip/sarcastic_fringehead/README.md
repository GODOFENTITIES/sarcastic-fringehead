# Sarcastic Fringehead (v0.1)

**Sarcastic Fringehead** is a high-performance, deterministic runtime AI governance and constitutional enforcement engine written in Python.

## Core Architectural Guarantees

1. **Separation of Authority and Prediction:** The deterministic constitutional engine holds sole final authority (`ALLOW`, `BLOCK`, `REVIEW`). External evaluators (such as `jev_decision_layer` or `human_support_supervisor`) only supply input signals or adjudicate escalated `REVIEW` cases.
2. **Zero `eval()` / `exec()` Surface:** A deterministic AST condition evaluator traverses nested `all` / `any` boolean trees, safely resolves dot-notation context paths (returning `False` on missing keys without throwing `KeyError`), and supports dynamic cross-field references via `value_ref`.
3. **Strict Hierarchical Conflict Resolution:**
   - **Lowest `level` number wins** (`Level 0` > `Level 1` > `Level 2` > `Level 3`).
   - **Most restrictive action wins** within the same level (`BLOCK` > `REVIEW` > `ALLOW`).
   - **Highest `priority_weight` wins** as the deterministic tie-breaker.
4. **Role-Gated Constitutional Amendments:** RBAC controller enforces level permissions, `immutable_by_operator` protections, privilege-escalation guards, and distinct cryptographic/quorum signature thresholds before bumping the constitution semantic patch version (`1.0.0` -> `1.0.1`).
5. **Tamper-Evident Canonical Audit Ledger:** Append-only SHA-256 hash chain over canonical JSON (`sort_keys=True, separators=(",", ":")`) starting from a 64-zero genesis hash, recording `previous_hash`, `entry_hash`, `policy_version`, `triggered_rule_ids`, and `latency_ms` via `time.perf_counter_ns()`.

## Project Structure

```text
sarcastic_fringehead/
├── config/
│   └── constitution.yaml
├── src/
│   ├── __init__.py
│   ├── models.py          # Strict Pydantic schemas
│   ├── engine.py          # Safe AST/rule evaluator & conflict resolver
│   ├── governance.py      # RBAC amendment controller & quorum validator
│   ├── audit.py           # Canonical SHA-256 hash-chained ledger
│   └── main.py            # FastAPI endpoints & in-memory state
├── tests/
│   └── test_fringehead_v01.py
├── requirements.txt
└── README.md
```

## Running Tests & FastAPI Server

```bash
# Run the automated verification suite
pytest -v

# Start the FastAPI gateway
uvicorn src.main:app --host 0.0.0.0 --port 8000
```
