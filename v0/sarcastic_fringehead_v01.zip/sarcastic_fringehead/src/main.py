"""FastAPI Gateway & In-Memory Runtime State for Sarcastic Fringehead (v0.1).

Exposes:
- POST /v1/evaluate
- POST /v1/governance/amend
- GET  /v1/audit/verify
- GET  /v1/metrics
"""

from __future__ import annotations

import math
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException, status

from .audit import AuditLedger
from .engine import ConstitutionalEngine
from .governance import GovernanceManager, UnauthorizedAmendmentError
from .models import (
    AmendmentProposal,
    AmendmentResult,
    EvaluationDecision,
    EvaluationRequest,
)

DEFAULT_CONSTITUTION_PATH = (
    Path(__file__).resolve().parent.parent / "config" / "constitution.yaml"
)


def compute_percentile(sorted_values: List[float], percentile: float) -> float:
    """Compute nearest-rank / linear interpolated percentile from a sorted list of floats."""
    if not sorted_values:
        return 0.0
    n = len(sorted_values)
    if n == 1:
        return round(sorted_values[0], 6)
    pos = (percentile / 100.0) * (n - 1)
    lower = int(math.floor(pos))
    upper = int(math.ceil(pos))
    if lower == upper:
        return round(sorted_values[lower], 6)
    weight = pos - lower
    interpolated = sorted_values[lower] * (1.0 - weight) + sorted_values[upper] * weight
    return round(interpolated, 6)


class FringeheadState:
    """Container holding active ConstitutionalEngine, GovernanceManager, AuditLedger, and metrics."""

    def __init__(self, constitution_path: Optional[Path] = None) -> None:
        path = constitution_path or DEFAULT_CONSTITUTION_PATH
        self.audit_ledger = AuditLedger()
        self.engine = ConstitutionalEngine.from_yaml(path, audit_ledger=self.audit_ledger)
        self.governance = GovernanceManager(
            constitution=self.engine.constitution,
            audit_ledger=self.audit_ledger,
        )
        self.latencies_ms: List[float] = []
        self.decision_counts: Dict[str, int] = {
            "ALLOW": 0,
            "BLOCK": 0,
            "REVIEW": 0,
        }


def create_app(constitution_path: Optional[Path] = None) -> FastAPI:
    """Create and configure the Sarcastic Fringehead FastAPI application."""
    app = FastAPI(
        title="Sarcastic Fringehead Constitutional Governance Engine",
        version="0.1.0",
        description="Deterministic runtime AI governance, role-gated amendments, and tamper-evident audit ledger.",
    )

    state = FringeheadState(constitution_path=constitution_path)
    app.state.fringehead = state

    @app.post("/v1/evaluate", response_model=EvaluationDecision)
    def evaluate_request(request: EvaluationRequest) -> EvaluationDecision:
        decision = state.engine.evaluate(request)
        state.latencies_ms.append(decision.latency_ms)
        state.decision_counts[decision.decision] = (
            state.decision_counts.get(decision.decision, 0) + 1
        )
        return decision

    @app.post("/v1/governance/amend", response_model=AmendmentResult)
    def amend_constitution(proposal: AmendmentProposal) -> AmendmentResult:
        try:
            return state.governance.apply_amendment(proposal)
        except UnauthorizedAmendmentError as exc:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=str(exc),
            ) from exc

    @app.get("/v1/audit/verify")
    def verify_audit_ledger() -> Dict[str, Any]:
        is_valid, tampered_index = state.audit_ledger.verify_chain()
        return {
            "valid": is_valid,
            "is_valid": is_valid,
            "tampered_index": tampered_index,
            "total_records": len(state.audit_ledger.records),
            "head_hash": state.audit_ledger.last_hash,
            "policy_version": state.engine.constitution.version,
        }

    @app.get("/v1/metrics")
    def get_metrics() -> Dict[str, Any]:
        sorted_latencies = sorted(state.latencies_ms)
        p50 = compute_percentile(sorted_latencies, 50.0)
        p95 = compute_percentile(sorted_latencies, 95.0)
        return {
            "total_requests": len(state.latencies_ms),
            "p50_latency_ms": p50,
            "p95_latency_ms": p95,
            "decision_counts": dict(state.decision_counts),
            "policy_version": state.engine.constitution.version,
        }

    return app


app = create_app()
