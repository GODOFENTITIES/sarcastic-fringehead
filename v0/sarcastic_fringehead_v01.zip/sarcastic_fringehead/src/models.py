"""Strict Pydantic schemas for Sarcastic Fringehead (v0.1).

Supports both Pydantic v2 (ConfigDict, model_validator, model_dump, model_validate)
and Pydantic v1.10+ runtime compatibility seamlessly.
"""

from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional, Union
import pydantic
from pydantic import BaseModel, Field

PYDANTIC_V2 = int(pydantic.__version__.split(".")[0]) >= 2

if not PYDANTIC_V2:
    from pydantic import root_validator, Extra
else:
    from pydantic import ConfigDict, model_validator


ActionType = Literal["ALLOW", "BLOCK", "REVIEW"]
OperatorType = Literal[
    "equals",
    "not_equals",
    "in",
    "not_in",
    "greater_than",
    "less_than",
    "greater_than_or_equals",
    "less_than_or_equals",
]
AuditSeverityType = Literal["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"]


class StrictBaseModel(BaseModel):
    """Base model enforcing extra='forbid' and Providing Pydantic v2 methods uniformly."""

    if PYDANTIC_V2:
        model_config = ConfigDict(extra="forbid", validate_assignment=True)
    else:
        class Config:
            extra = Extra.forbid
            validate_assignment = True

        def model_dump(self, **kwargs: Any) -> Dict[str, Any]:
            return self.dict(**kwargs)

        def model_dump_json(self, **kwargs: Any) -> str:
            return self.json(**kwargs)

        def model_copy(self, *, update: Optional[Dict[str, Any]] = None, deep: bool = False):
            return self.copy(update=update, deep=deep)

        @classmethod
        def model_validate(cls, obj: Any):
            return cls.parse_obj(obj)


class LeafCondition(StrictBaseModel):
    """Atomic leaf condition comparing a dot-notation field against a literal value or dynamic reference."""

    field: str = Field(..., min_length=1, description="Dot-notation path in evaluation context")
    operator: OperatorType
    value: Optional[Any] = None
    value_ref: Optional[str] = Field(
        default=None, description="Dynamic dot-notation path in context to resolve right-hand value"
    )

    if PYDANTIC_V2:
        @model_validator(mode="after")
        def check_value_or_value_ref(self) -> "LeafCondition":
            if self.value is None and self.value_ref is None:
                raise ValueError("LeafCondition must specify either 'value' or 'value_ref'.")
            if self.value is not None and self.value_ref is not None:
                raise ValueError("LeafCondition cannot specify both 'value' and 'value_ref'.")
            return self
    else:
        @root_validator
        def check_value_or_value_ref(cls, values: Dict[str, Any]) -> Dict[str, Any]:
            val = values.get("value")
            val_ref = values.get("value_ref")
            if val is None and val_ref is None:
                raise ValueError("LeafCondition must specify either 'value' or 'value_ref'.")
            if val is not None and val_ref is not None:
                raise ValueError("LeafCondition cannot specify both 'value' and 'value_ref'.")
            return values


class ConditionGroup(StrictBaseModel):
    """Boolean AST node supporting nested 'all' (AND) or 'any' (OR) condition trees."""

    all: Optional[List[Union["ConditionGroup", LeafCondition]]] = None
    any: Optional[List[Union["ConditionGroup", LeafCondition]]] = None

    if PYDANTIC_V2:
        @model_validator(mode="after")
        def check_all_or_any(self) -> "ConditionGroup":
            has_all = self.all is not None
            has_any = self.any is not None
            if has_all == has_any:
                raise ValueError("ConditionGroup must specify exactly one of 'all' or 'any'.")
            if has_all and len(self.all or []) == 0:
                raise ValueError("'all' list cannot be empty.")
            if has_any and len(self.any or []) == 0:
                raise ValueError("'any' list cannot be empty.")
            return self
    else:
        @root_validator
        def check_all_or_any(cls, values: Dict[str, Any]) -> Dict[str, Any]:
            all_list = values.get("all")
            any_list = values.get("any")
            has_all = all_list is not None
            has_any = any_list is not None
            if has_all == has_any:
                raise ValueError("ConditionGroup must specify exactly one of 'all' or 'any'.")
            if has_all and len(all_list) == 0:
                raise ValueError("'all' list cannot be empty.")
            if has_any and len(any_list) == 0:
                raise ValueError("'any' list cannot be empty.")
            return values


if not PYDANTIC_V2:
    ConditionGroup.update_forward_refs()


class EscalationTrigger(StrictBaseModel):
    """Secondary trigger flagging a rule for REVIEW escalation even when main condition does not match."""

    when_field: str = Field(..., min_length=1)
    operator: OperatorType
    value: Optional[Any] = None
    value_ref: Optional[str] = None
    route_to: str = Field(..., min_length=1)

    if PYDANTIC_V2:
        @model_validator(mode="after")
        def check_trigger_value(self) -> "EscalationTrigger":
            if self.value is None and self.value_ref is None:
                raise ValueError("EscalationTrigger must specify 'value' or 'value_ref'.")
            return self
    else:
        @root_validator
        def check_trigger_value(cls, values: Dict[str, Any]) -> Dict[str, Any]:
            if values.get("value") is None and values.get("value_ref") is None:
                raise ValueError("EscalationTrigger must specify 'value' or 'value_ref'.")
            return values


class RuleScope(StrictBaseModel):
    """Execution rail and jurisdiction scoping for a constitutional rule."""

    stages: List[str] = Field(..., min_items=1)
    jurisdictions: Optional[List[str]] = None


class Rule(StrictBaseModel):
    """Single constitutional policy rule with priority hierarchy and deterministic AST condition."""

    id: str = Field(..., min_length=1)
    name: str = Field(..., min_length=1)
    level: int = Field(..., ge=0, le=3)
    priority_weight: int = Field(..., ge=0)
    owner_role: str = Field(..., min_length=1)
    immutable_by_operator: bool = False
    scope: RuleScope
    deterministic_condition: ConditionGroup
    escalation_trigger: Optional[EscalationTrigger] = None
    action: ActionType
    escalation_target: Optional[str] = None
    violation_code: Optional[str] = None
    audit_severity: AuditSeverityType = "INFO"


class RoleSpec(StrictBaseModel):
    """RBAC role specification governing amendment authority and quorum thresholds."""

    description: str
    can_amend_levels: List[int]
    requires_quorum_signatures: int = Field(..., ge=1)
    can_read_audit_ledger: bool = False


class ConstitutionDefaults(StrictBaseModel):
    """Default fallback behavior when no rules match or external evaluator times out."""

    unmatched_action: ActionType = "ALLOW"
    on_evaluator_timeout: ActionType = "REVIEW"


class Constitution(StrictBaseModel):
    """Root Constitutional Policy model."""

    schema_version: str
    constitution_id: str
    version: str
    last_updated: str
    defaults: ConstitutionDefaults
    roles: Dict[str, RoleSpec]
    rules: List[Rule]


class EvaluationRequest(StrictBaseModel):
    """Runtime request payload submitted to the constitutional policy engine."""

    request_id: str = Field(..., min_length=1)
    stage: str = Field(..., min_length=1)
    jurisdiction: str = Field(default="GLOBAL", min_length=1)
    session: Dict[str, Any] = Field(default_factory=dict)
    user: Dict[str, Any] = Field(default_factory=dict)
    tool: Dict[str, Any] = Field(default_factory=dict)
    context: Dict[str, Any] = Field(default_factory=dict)
    classifier: Dict[str, Any] = Field(default_factory=dict)


class EvaluationDecision(StrictBaseModel):
    """Authoritative deterministic decision output returned by the engine."""

    request_id: Optional[str] = None
    decision: ActionType
    winning_rule_id: Optional[str] = None
    matched_rule_ids: List[str] = Field(default_factory=list)
    escalated_to: Optional[str] = None
    violation_code: Optional[str] = None
    audit_severity: Optional[AuditSeverityType] = None
    policy_version: str
    latency_ms: float
    audit_entry_hash: str


class AmendmentProposal(StrictBaseModel):
    """Role-gated constitutional amendment request requiring cryptographic/quorum signatures."""

    proposer_role: str = Field(..., min_length=1)
    signatures: List[str] = Field(..., description="Distinct signer identifiers")
    target_rule_id: str = Field(..., min_length=1)
    updated_rule: Rule
    reason: str = Field(..., min_length=1)


class AmendmentResult(StrictBaseModel):
    """Response returned upon a validated constitutional rule amendment."""

    status: Literal["AMENDED"] = "AMENDED"
    previous_version: str
    new_version: str
    target_rule_id: str
    proposer_role: str
    quorum_signatures_count: int
    audit_entry_hash: str
