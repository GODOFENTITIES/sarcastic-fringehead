"""Deterministic Policy Engine & Conflict Resolver for Sarcastic Fringehead (v0.1).

Strictly avoids `eval()` and `exec()`. Parses nested `all` / `any` boolean trees,
resolves dot-notation fields and dynamic `value_ref` references, checks `escalation_trigger`
conditions, and performs deterministic hierarchical conflict resolution.
"""

from __future__ import annotations

from dataclasses import dataclass
import time
from typing import Any, Callable, Dict, List, Optional, Tuple, Union
from pathlib import Path
import yaml

from .audit import AuditLedger
from .models import (
    ActionType,
    AuditSeverityType,
    ConditionGroup,
    Constitution,
    EscalationTrigger,
    EvaluationDecision,
    EvaluationRequest,
    LeafCondition,
    Rule,
)

_MISSING = object()

ACTION_RESTRICTIVENESS: Dict[ActionType, int] = {
    "BLOCK": 3,
    "REVIEW": 2,
    "ALLOW": 1,
}


def resolve_dot_path(context_map: Dict[str, Any], path: str) -> Any:
    """Safely traverse nested dictionaries using dot-notation paths.

    Returns `_MISSING` sentinel if any key along the path is missing or non-traversable.
    Never raises KeyError, IndexError, or TypeError.
    """
    if not path:
        return _MISSING
    current: Any = context_map
    for segment in path.split("."):
        if isinstance(current, dict) and segment in current:
            current = current[segment]
        else:
            return _MISSING
    return current


def _op_equals(left: Any, right: Any) -> bool:
    if type(left) is not type(right) and isinstance(left, (int, float)) and isinstance(right, (int, float)):
        if isinstance(left, bool) or isinstance(right, bool):
            return False
        return float(left) == float(right)
    if isinstance(left, bool) != isinstance(right, bool):
        return False
    return left == right


def _op_not_equals(left: Any, right: Any) -> bool:
    return not _op_equals(left, right)


def _op_in(left: Any, right: Any) -> bool:
    if not isinstance(right, (list, tuple, set, frozenset, str)):
        return False
    if isinstance(right, str):
        return isinstance(left, str) and left in right
    return any(_op_equals(left, item) for item in right)


def _op_not_in(left: Any, right: Any) -> bool:
    if not isinstance(right, (list, tuple, set, frozenset, str)):
        return False
    return not _op_in(left, right)


def _is_comparable_number(val: Any) -> bool:
    return isinstance(val, (int, float)) and not isinstance(val, bool)


def _op_gt(left: Any, right: Any) -> bool:
    if _is_comparable_number(left) and _is_comparable_number(right):
        return float(left) > float(right)
    if isinstance(left, str) and isinstance(right, str):
        return left > right
    return False


def _op_lt(left: Any, right: Any) -> bool:
    if _is_comparable_number(left) and _is_comparable_number(right):
        return float(left) < float(right)
    if isinstance(left, str) and isinstance(right, str):
        return left < right
    return False


def _op_gte(left: Any, right: Any) -> bool:
    if _is_comparable_number(left) and _is_comparable_number(right):
        return float(left) >= float(right)
    if isinstance(left, str) and isinstance(right, str):
        return left >= right
    return False


def _op_lte(left: Any, right: Any) -> bool:
    if _is_comparable_number(left) and _is_comparable_number(right):
        return float(left) <= float(right)
    if isinstance(left, str) and isinstance(right, str):
        return left <= right
    return False


OPERATORS: Dict[str, Callable[[Any, Any], bool]] = {
    "equals": _op_equals,
    "not_equals": _op_not_equals,
    "in": _op_in,
    "not_in": _op_not_in,
    "greater_than": _op_gt,
    "less_than": _op_lt,
    "greater_than_or_equals": _op_gte,
    "less_than_or_equals": _op_lte,
}


@dataclass(frozen=True)
class MatchedCandidate:
    """Internal representation of a matched rule or escalation trigger candidate."""

    rule_id: str
    level: int
    effective_action: ActionType
    priority_weight: int
    escalated_to: Optional[str]
    violation_code: Optional[str]
    audit_severity: AuditSeverityType
    is_escalation_trigger: bool = False

    def conflict_sort_key(self) -> Tuple[int, int, int]:
        """Return tuple key where smaller tuple values win in ascending sort:
        1. Lowest `level` number wins (0 beats 1, 2, 3) -> `self.level`
        2. Most restrictive action wins (`BLOCK` [3] > `REVIEW` [2] > `ALLOW` [1]) -> `-ACTION_RESTRICTIVENESS`
        3. Highest `priority_weight` wins -> `-self.priority_weight`
        """
        return (
            self.level,
            -ACTION_RESTRICTIVENESS[self.effective_action],
            -self.priority_weight,
        )


class ConstitutionalEngine:
    """High-performance, deterministic runtime policy engine."""

    def __init__(self, constitution: Constitution, audit_ledger: Optional[AuditLedger] = None) -> None:
        self.constitution: Constitution = constitution
        self.audit_ledger: AuditLedger = audit_ledger if audit_ledger is not None else AuditLedger()

    @classmethod
    def from_yaml(
        cls, yaml_path: Union[str, Path], audit_ledger: Optional[AuditLedger] = None
    ) -> "ConstitutionalEngine":
        """Load and validate a Constitution YAML file and initialize the engine."""
        path = Path(yaml_path)
        with path.open("r", encoding="utf-8") as fh:
            raw_data = yaml.safe_load(fh)
        constitution = Constitution.model_validate(raw_data)
        return cls(constitution=constitution, audit_ledger=audit_ledger)

    def _build_context_map(self, request: EvaluationRequest) -> Dict[str, Any]:
        """Construct unified root dictionary for dot-notation traversal."""
        return {
            "request_id": request.request_id,
            "stage": request.stage,
            "jurisdiction": request.jurisdiction,
            "session": request.session,
            "user": request.user,
            "tool": request.tool,
            "context": request.context,
            "classifier": request.classifier,
        }

    def evaluate_leaf(self, leaf: LeafCondition, context_map: Dict[str, Any]) -> bool:
        """Safely evaluate a single LeafCondition against context_map without eval()."""
        left_val = resolve_dot_path(context_map, leaf.field)
        if left_val is _MISSING:
            return False

        if leaf.value_ref is not None:
            right_val = resolve_dot_path(context_map, leaf.value_ref)
            if right_val is _MISSING:
                return False
        else:
            right_val = leaf.value

        op_func = OPERATORS.get(leaf.operator)
        if op_func is None:
            return False

        return op_func(left_val, right_val)

    def evaluate_condition_group(
        self, group: Union[ConditionGroup, LeafCondition], context_map: Dict[str, Any]
    ) -> bool:
        """Recursively evaluate nested `all` / `any` boolean trees."""
        if isinstance(group, LeafCondition):
            return self.evaluate_leaf(group, context_map)

        if group.all is not None:
            return all(self.evaluate_condition_group(child, context_map) for child in group.all)

        if group.any is not None:
            return any(self.evaluate_condition_group(child, context_map) for child in group.any)

        return False

    def evaluate_escalation_trigger(
        self, trigger: EscalationTrigger, context_map: Dict[str, Any]
    ) -> bool:
        """Evaluate a rule's secondary escalation_trigger safely."""
        left_val = resolve_dot_path(context_map, trigger.when_field)
        if left_val is _MISSING:
            return False

        if trigger.value_ref is not None:
            right_val = resolve_dot_path(context_map, trigger.value_ref)
            if right_val is _MISSING:
                return False
        else:
            right_val = trigger.value

        op_func = OPERATORS.get(trigger.operator)
        if op_func is None:
            return False

        return op_func(left_val, right_val)

    @staticmethod
    def _rule_in_scope(rule: Rule, stage: str, jurisdiction: str) -> bool:
        """Check whether a rule applies to the current execution stage and jurisdiction."""
        if stage not in rule.scope.stages:
            return False
        if rule.scope.jurisdictions:
            if "GLOBAL" not in rule.scope.jurisdictions and jurisdiction not in rule.scope.jurisdictions:
                return False
        return True

    def evaluate(self, request: EvaluationRequest) -> EvaluationDecision:
        """Evaluate an EvaluationRequest deterministically, resolve conflicts, and append to audit ledger."""
        start_ns = time.perf_counter_ns()
        context_map = self._build_context_map(request)

        candidates: List[MatchedCandidate] = []
        matched_rule_ids: List[str] = []

        for rule in self.constitution.rules:
            if not self._rule_in_scope(rule, request.stage, request.jurisdiction):
                continue

            main_matched = self.evaluate_condition_group(rule.deterministic_condition, context_map)
            if main_matched:
                candidates.append(
                    MatchedCandidate(
                        rule_id=rule.id,
                        level=rule.level,
                        effective_action=rule.action,
                        priority_weight=rule.priority_weight,
                        escalated_to=rule.escalation_target if rule.action == "REVIEW" else None,
                        violation_code=rule.violation_code,
                        audit_severity=rule.audit_severity,
                        is_escalation_trigger=False,
                    )
                )
                matched_rule_ids.append(rule.id)
            elif rule.escalation_trigger is not None:
                # Even if main deterministic_condition does not match, check escalation_trigger
                if self.evaluate_escalation_trigger(rule.escalation_trigger, context_map):
                    candidates.append(
                        MatchedCandidate(
                            rule_id=rule.id,
                            level=rule.level,
                            effective_action="REVIEW",
                            priority_weight=rule.priority_weight,
                            escalated_to=rule.escalation_trigger.route_to,
                            violation_code=rule.violation_code,
                            audit_severity=rule.audit_severity,
                            is_escalation_trigger=True,
                        )
                    )
                    matched_rule_ids.append(rule.id)

        if candidates:
            # Resolve conflicts deterministically:
            # 1. Lowest level wins (0 < 1 < 2 < 3)
            # 2. Most restrictive action wins (BLOCK > REVIEW > ALLOW)
            # 3. Highest priority_weight wins
            candidates.sort(key=lambda c: c.conflict_sort_key())
            winner = candidates[0]
            decision_action: ActionType = winner.effective_action
            winning_rule_id: Optional[str] = winner.rule_id
            escalated_to: Optional[str] = winner.escalated_to
            violation_code: Optional[str] = winner.violation_code
            audit_severity: Optional[AuditSeverityType] = winner.audit_severity
        else:
            decision_action = self.constitution.defaults.unmatched_action
            winning_rule_id = None
            escalated_to = None
            violation_code = None
            audit_severity = "INFO"

        elapsed_ns = time.perf_counter_ns() - start_ns
        latency_ms = round(elapsed_ns / 1_000_000.0, 6)

        audit_record = self.audit_ledger.append_record(
            event_type="EVALUATION",
            request_id=request.request_id,
            policy_version=self.constitution.version,
            decision=decision_action,
            winning_rule_id=winning_rule_id,
            triggered_rule_ids=matched_rule_ids,
            escalated_to=escalated_to,
            latency_ms=latency_ms,
            metadata={
                "stage": request.stage,
                "jurisdiction": request.jurisdiction,
                "violation_code": violation_code,
                "audit_severity": audit_severity,
            },
        )

        return EvaluationDecision(
            request_id=request.request_id,
            decision=decision_action,
            winning_rule_id=winning_rule_id,
            matched_rule_ids=matched_rule_ids,
            escalated_to=escalated_to,
            violation_code=violation_code,
            audit_severity=audit_severity,
            policy_version=self.constitution.version,
            latency_ms=latency_ms,
            audit_entry_hash=audit_record.entry_hash,
        )
