"""Phase 2 Verification Suite for Sarcastic Fringehead (v0.1).

Covers all 6 mandatory Phase 2 scenarios:
1. Accurate Math Verification (PASS -> ALLOW)
2. Hallucinated Math Catch (BLOCK via L1-VAL-002 -> ERR_L1_VALIDATION_FAILED)
3. Unsafe Expression Rejection (AST whitelist rejects `__import__('os').system('ls')` without executing)
4. Factual Contradiction Catch (BLOCK via L1-VAL-002 when `refund_eligible: true` contradicts `trusted_facts`)
5. Pluggable Escalation Resolution & Low-Confidence Guardrail (5a: 0.92 -> ALLOW; 5b: 0.55 -> stays REVIEW)
6. Escalation Timeout Fail-Safe (300ms sleep vs 50ms timeout -> catches TimeoutError, falls back to REVIEW, logs to audit ledger)
"""

from __future__ import annotations

import asyncio
from pathlib import Path
import pytest
from fastapi.testclient import TestClient

from src.audit import AuditLedger
from src.engine import ConstitutionalEngine
from src.escalation import EscalationProvider, EscalationRouter
from src.main import create_app
from src.models import (
    ActionType,
    EscalationResult,
    EvaluationRequest,
    ValidateAndEvaluateRequest,
)
from src.validation import UnsafeMathExpressionError, ValidationEngine, safe_eval_math_expr

CONSTITUTION_YAML = Path(__file__).resolve().parent.parent / "config" / "constitution.yaml"


def _build_phase2_stack():
    ledger = AuditLedger()
    val_engine = ValidationEngine()
    router = EscalationRouter(
        default_timeout_ms=150.0,
        confidence_threshold=0.85,
        on_timeout_action="REVIEW",
        audit_ledger=ledger,
    )
    engine = ConstitutionalEngine.from_yaml(
        CONSTITUTION_YAML,
        audit_ledger=ledger,
        validation_engine=val_engine,
        escalation_router=router,
    )
    return engine, val_engine, router, ledger


def test_phase2_scenario_1_accurate_math_verification_pass():
    """1. Accurate Math Verification (PASS):
    Response containing 'Your total is 125 * 4 = 500 USD' passes validation
    (math_check_passed == True) and returns ALLOW.
    """
    app = create_app(CONSTITUTION_YAML)
    client = TestClient(app)

    payload = ValidateAndEvaluateRequest(
        request_id="req-p2-math-pass",
        stage="output_rail",
        jurisdiction="GLOBAL",
        query="What is my total for 4 units at 125 USD each?",
        response_text="Your total is 125 * 4 = 500 USD, and with tax (40 * 1.15) = 46 USD.",
    )

    resp = client.post("/v1/validate-and-evaluate", json=payload.model_dump())
    assert resp.status_code == 200
    data = resp.json()

    assert data["validation_report"]["math_check_passed"] is True
    assert data["validation_report"]["overall_status"] == "PASS"
    assert data["validation_report"]["failed_equations"] == []
    assert data["decision"] == "ALLOW"
    assert data["winning_rule_id"] is None


def test_phase2_scenario_2_hallucinated_math_catch_block():
    """2. Hallucinated Math Catch (BLOCK via L1-VAL-002):
    Response containing 'Your refund is 125 * 4 = 550 USD' fails AST math check
    (math_check_passed == False), triggers L1-VAL-002, and returns BLOCK (ERR_L1_VALIDATION_FAILED).
    """
    app = create_app(CONSTITUTION_YAML)
    client = TestClient(app)

    payload = ValidateAndEvaluateRequest(
        request_id="req-p2-math-fail",
        stage="output_rail",
        jurisdiction="GLOBAL",
        query="Calculate my refund for 4 items at 125 USD.",
        response_text="Your refund is 125 * 4 = 550 USD.",
    )

    resp = client.post("/v1/validate-and-evaluate", json=payload.model_dump())
    assert resp.status_code == 200
    data = resp.json()

    assert data["validation_report"]["math_check_passed"] is False
    assert len(data["validation_report"]["failed_equations"]) == 1
    assert "125 * 4 = 550" in data["validation_report"]["failed_equations"][0]
    assert data["decision"] == "BLOCK"
    assert data["winning_rule_id"] == "L1-VAL-002"
    assert data["violation_code"] == "ERR_L1_VALIDATION_FAILED"


def test_phase2_scenario_3_unsafe_expression_rejection():
    """3. Unsafe Expression Rejection:
    Ensure the math parser safely ignores or rejects non-arithmetic code injection strings
    (e.g., `__import__('os').system('ls')`) without executing them.
    """
    val_engine = ValidationEngine()

    # Direct AST evaluation of code injection must raise UnsafeMathExpressionError without executing
    with pytest.raises(UnsafeMathExpressionError):
        safe_eval_math_expr("__import__('os').system('ls')")

    with pytest.raises(UnsafeMathExpressionError):
        safe_eval_math_expr("eval('1 + 1')")

    with pytest.raises(UnsafeMathExpressionError):
        safe_eval_math_expr("(lambda: 1)()")

    # ValidationEngine.validate() safely records/ignores the injection attempt in response_text
    malicious_response = (
        "Calculation: __import__('os').system('ls') = 0 and valid math 10 + 20 - 5 = 25."
    )
    report = val_engine.validate(
        query="Test injection resilience",
        response_text=malicious_response,
    )
    assert report.math_check_passed is True
    assert len(report.rejected_unsafe_expressions) >= 1
    assert any("__import__" in item for item in report.rejected_unsafe_expressions)


def test_phase2_scenario_4_factual_contradiction_catch_block():
    """4. Factual Contradiction Catch (BLOCK via L1-VAL-002):
    Candidate response claims Order_101 has refund_eligible: true, while trusted_facts
    states refund_eligible: false. Assert unverified_factual_claims == 1 and engine returns BLOCK.
    """
    app = create_app(CONSTITUTION_YAML)
    client = TestClient(app)

    payload = ValidateAndEvaluateRequest(
        request_id="req-p2-fact-contradiction",
        stage="output_rail",
        jurisdiction="GLOBAL",
        query="Is Order_101 eligible for a refund?",
        response_text="Yes, Order_101 is eligible for a full refund.",
        trusted_facts=[
            {
                "entity": "Order_101",
                "attribute": "refund_eligible",
                "value": False,
                "source_id": "doc_orders_db",
            }
        ],
        structured_claims=[
            {
                "entity": "Order_101",
                "attribute": "refund_eligible",
                "value": True,
                "source_id": "doc_orders_db",
            }
        ],
    )

    resp = client.post("/v1/validate-and-evaluate", json=payload.model_dump())
    assert resp.status_code == 200
    data = resp.json()

    assert data["validation_report"]["unverified_factual_claims"] == 1
    assert data["validation_report"]["overall_status"] == "REJECT"
    assert data["decision"] == "BLOCK"
    assert data["winning_rule_id"] == "L1-VAL-002"
    assert data["violation_code"] == "ERR_L1_VALIDATION_FAILED"


def test_phase2_scenario_5_pluggable_escalation_and_low_confidence_guardrail():
    """5. Pluggable Escalation Resolution & Low-Confidence Guardrail:
    - Register a mock custom EscalationProvider plugin.
    - Test 5a: Plugin returns ALLOW with confidence 0.92 (above 0.85 threshold) on a REVIEW case -> resolves to ALLOW.
    - Test 5b: Plugin returns ALLOW with confidence 0.55 (below threshold) -> remains REVIEW (proving confidence is not blindly trusted).
    """

    class MockCustomEscalationPlugin:
        def __init__(self, confidence: float, recommended: ActionType = "ALLOW") -> None:
            self.name = "mock_custom_evaluator"
            self.confidence = confidence
            self.recommended: ActionType = recommended

        async def evaluate(self, request: EvaluationRequest, rule_id: str) -> EscalationResult:
            return EscalationResult(
                provider_name=self.name,
                recommended_action=self.recommended,
                confidence=self.confidence,
                risk_label="MOCK_EVALUATION_SIGNAL",
                latency_ms=0.05,
            )

    engine, _, router, _ = _build_phase2_stack()
    assert isinstance(MockCustomEscalationPlugin(0.92), EscalationProvider)

    review_payload = ValidateAndEvaluateRequest(
        request_id="req-p2-esc-5a",
        stage="execution_rail",
        jurisdiction="GLOBAL",
        query="Send summary over webhook",
        response_text="Sending summary across network.",
        context={"contains_untrusted_retrieval": True},
        tool={"side_effect_class": "external_network_send"},
        session={"explicit_user_confirmation": False},
    )

    # Test 5a: High confidence (0.92 >= 0.85) -> resolves REVIEW to ALLOW
    router.register("secondary_risk_evaluator", MockCustomEscalationPlugin(confidence=0.92))
    dec_5a = asyncio.run(engine.validate_and_evaluate(review_payload))
    assert dec_5a.winning_rule_id == "L1-SEC-001"
    assert dec_5a.decision == "ALLOW"
    assert dec_5a.escalation_resolution is not None
    assert dec_5a.escalation_resolution.initial_decision == "REVIEW"
    assert dec_5a.escalation_resolution.final_decision == "ALLOW"
    assert dec_5a.escalation_resolution.low_confidence_fallback is False

    # Test 5b: Low confidence (0.55 < 0.85) -> remains REVIEW
    review_payload_5b = review_payload.model_copy(update={"request_id": "req-p2-esc-5b"})
    router.register("secondary_risk_evaluator", MockCustomEscalationPlugin(confidence=0.55))
    dec_5b = asyncio.run(engine.validate_and_evaluate(review_payload_5b))
    assert dec_5b.winning_rule_id == "L1-SEC-001"
    assert dec_5b.decision == "REVIEW"
    assert dec_5b.escalation_resolution is not None
    assert dec_5b.escalation_resolution.final_decision == "REVIEW"
    assert dec_5b.escalation_resolution.low_confidence_fallback is True
    assert dec_5b.escalation_resolution.resolution_reason == "LOW_CONFIDENCE_GUARDRAIL"


def test_phase2_scenario_6_escalation_timeout_failsafe():
    """6. Escalation Timeout Fail-Safe:
    Register a slow mock plugin that sleeps for 300ms when timeout is 50ms.
    Assert the router catches asyncio.TimeoutError, falls back safely to REVIEW,
    and records the timeout in the tamper-evident audit ledger.
    """

    class SlowTimeoutPlugin:
        name = "slow_timeout_plugin"

        async def evaluate(self, request: EvaluationRequest, rule_id: str) -> EscalationResult:
            await asyncio.sleep(0.300)  # 300ms sleep
            return EscalationResult(
                provider_name=self.name,
                recommended_action="ALLOW",
                confidence=0.99,
                risk_label="NEVER_REACHED",
                latency_ms=300.0,
            )

    engine, _, router, ledger = _build_phase2_stack()
    router.register("secondary_risk_evaluator", SlowTimeoutPlugin())

    review_payload = ValidateAndEvaluateRequest(
        request_id="req-p2-timeout-6",
        stage="execution_rail",
        jurisdiction="GLOBAL",
        query="Trigger external send",
        response_text="Dispatching webhook.",
        context={"contains_untrusted_retrieval": True},
        tool={"side_effect_class": "external_network_send"},
        session={"explicit_user_confirmation": False},
    )

    decision = asyncio.run(
        engine.validate_and_evaluate(review_payload, escalation_timeout_ms=50.0)
    )

    assert decision.decision == "REVIEW"
    assert decision.escalation_resolution is not None
    assert decision.escalation_resolution.timed_out_or_errored is True
    assert decision.escalation_resolution.resolution_reason == "ESCALATION_TIMEOUT_OR_ERROR"
    assert decision.escalation_resolution.final_decision == "REVIEW"

    # Verify timeout was logged into the SHA-256 tamper-evident audit ledger and chain is valid
    is_valid, tampered_idx = ledger.verify_chain()
    assert is_valid is True
    assert tampered_idx is None
    last_record = ledger.records[-1]
    assert last_record.request_id == "req-p2-timeout-6"
    assert last_record.decision == "REVIEW"
    assert last_record.metadata["resolution_reason"] == "ESCALATION_TIMEOUT_OR_ERROR"
    assert last_record.metadata["timed_out_or_errored"] is True


def test_phase2_authority_boundary_block_cannot_be_overridden():
    """Verify strict authority boundary: even if an escalation plugin recommends ALLOW
    with 1.0 confidence, a deterministic BLOCK from Level 0 or Level 1 is never downgraded.
    """

    class AlwaysAllowPlugin:
        name = "rogue_allow_plugin"

        async def evaluate(self, request: EvaluationRequest, rule_id: str) -> EscalationResult:
            return EscalationResult(
                provider_name=self.name,
                recommended_action="ALLOW",
                confidence=1.0,
                risk_label="ROGUE_OVERRIDE_ATTEMPT",
                latency_ms=0.01,
            )

    engine, _, router, _ = _build_phase2_stack()
    router.register("secondary_risk_evaluator", AlwaysAllowPlugin())

    req = EvaluationRequest(
        request_id="req-p2-auth-boundary",
        stage="output_rail",
        jurisdiction="GLOBAL",
        session={"authenticated_user_id": "usr_101"},
        tool={"target_resource": "customer_records", "args": {"target_user_id": "usr_999"}},
    )
    dec = engine.evaluate(req)
    assert dec.decision == "BLOCK"

    res = asyncio.run(router.resolve(req, dec))
    assert res.final_decision == "BLOCK"
    assert res.authority_boundary_enforced is True
    assert dec.decision == "BLOCK"
