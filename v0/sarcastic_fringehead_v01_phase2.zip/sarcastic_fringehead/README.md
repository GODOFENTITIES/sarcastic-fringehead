# Sarcastic Fringehead (v0.1 — Phase 1 & Phase 2)

**Sarcastic Fringehead** is a high-performance, deterministic runtime AI governance, output validation, and constitutional enforcement engine written in Python.

## Core Architectural Guarantees

1. **Separation of Authority and Prediction:** The deterministic constitutional engine holds sole final authority (`ALLOW`, `BLOCK`, `REVIEW`). External or pluggable evaluators (`EscalationProvider`) can only advise on `REVIEW` cases and can **never** downgrade or override a deterministic `BLOCK`.
2. **Zero `eval()` / `exec()` Surface:**
   - **Policy Engine (`src/engine.py`):** Evaluates nested `all` / `any` boolean trees and resolves dot-notation fields (`tool.args.amount_usd`, `validation.math_check_passed`) and dynamic `value_ref` references without `eval()`.
   - **Symbolic Math Verifier (`src/validation.py`):** Parses inline equations (`125 * 4 = 500`, `(40 * 1.15) = 46`) via a strict `ast.NodeVisitor` whitelist (`Expression`, `BinOp`, `UnaryOp`, `Constant`, `Add`, `Sub`, `Mult`, `Div`, `Pow`, `USub`), rejecting non-arithmetic code injection strings (`__import__('os').system('ls')`) without execution.
3. **5-Check Deterministic Validation Engine (`src/validation.py`):**
   - **Stage 1 (Format & Completeness):** Non-empty bounds and optional JSON schema verification.
   - **Stage 2 (Deterministic Math & Calculation Check):** AST arithmetic verification within `1e-6` float tolerance.
   - **Stage 3 (Factual Grounding Check):** Cross-checks `structured_claims` against `trusted_facts` and source IDs.
   - **Stage 4 (Relevance & Internal Consistency):** Detects self-contradictions across claims and refusal payload leaks.
   - **Stage 5 (Confidence & Uncertainty Aggregation):** Produces `ValidationReport` (`PASS` | `RECHECK` | `REJECT`) and injects `validation.*` fields into `EvaluationRequest` to trigger `L1-VAL-002`.
4. **Vendor-Agnostic Pluggable Escalation (`src/escalation.py`):**
   - Clean `EscalationProvider` `Protocol` with built-in offline `LocalHeuristicEscalationProvider`.
   - `EscalationRouter` wraps provider calls in `asyncio.wait_for()` (default `150ms`), enforces a configurable confidence guardrail (`0.85`), and falls back deterministically to `defaults.on_evaluator_timeout` (`REVIEW`) on timeout or error.
5. **Role-Gated Constitutional Amendments (`src/governance.py`) & Tamper-Evident Audit Ledger (`src/audit.py`):**
   - Enforces RBAC level permissions, `immutable_by_operator` protections, and distinct quorum signatures.
   - Append-only SHA-256 hash chain over canonical JSON (`sort_keys=True, separators=(",", ":")`).

## Project Structure

```text
sarcastic_fringehead/
├── config/
│   └── constitution.yaml                  # Baseline policy including L1-VAL-002
├── src/
│   ├── __init__.py
│   ├── models.py                          # Strict Pydantic schemas (Phase 1 & 2)
│   ├── validation.py                      # 5-stage deterministic validation engine
│   ├── escalation.py                      # Vendor-agnostic EscalationProvider + Router
│   ├── engine.py                          # Safe AST/rule evaluator & conflict resolver
│   ├── governance.py                      # RBAC amendment controller & quorum validator
│   ├── audit.py                           # Canonical SHA-256 hash-chained ledger
│   └── main.py                            # FastAPI endpoints & in-memory state
├── tests/
│   ├── test_fringehead_v01.py             # Phase 1 verification suite (7 tests)
│   └── test_phase2_validation.py          # Phase 2 verification suite (7 tests)
├── requirements.txt
└── README.md
```

## Running Tests & FastAPI Server

```bash
# Run both Phase 1 and Phase 2 verification suites
pytest -v

# Start the FastAPI gateway
uvicorn src.main:app --host 0.0.0.0 --port 8000
```
