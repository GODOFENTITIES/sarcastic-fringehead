"""Sarcastic Fringehead (v0.1) — Deterministic Runtime AI Governance & Constitutional Enforcement Engine."""

__version__ = "0.1.0"
