"""Role-Gated Constitutional Amendment Controller & Quorum Validator.

Enforces RBAC amendment constraints, operator immutability locks, quorum signature
thresholds, and privilege escalation prevention.
"""

from __future__ import annotations

from datetime import datetime, timezone
import time
from typing import Optional
import uuid

from .audit import AuditLedger
from .models import AmendmentProposal, AmendmentResult, Constitution, Rule


class UnauthorizedAmendmentError(PermissionError):
    """Raised when a constitutional amendment violates RBAC, immutability, or quorum rules."""


def bump_patch_version(version_str: str) -> str:
    """Increment the semantic version patch component (e.g. '1.0.0' -> '1.0.1')."""
    parts = version_str.strip().split(".")
    if len(parts) != 3 or not all(p.isdigit() for p in parts):
        raise ValueError(f"Invalid semantic version format: '{version_str}'")
    major, minor, patch = int(parts[0]), int(parts[1]), int(parts[2])
    return f"{major}.{minor}.{patch + 1}"


class GovernanceManager:
    """Controller managing role-gated constitutional amendments and audit logging."""

    def __init__(self, constitution: Constitution, audit_ledger: AuditLedger) -> None:
        self.constitution = constitution
        self.audit_ledger = audit_ledger

    def _find_rule_index(self, rule_id: str) -> Optional[int]:
        for idx, rule in enumerate(self.constitution.rules):
            if rule.id == rule_id:
                return idx
        return None

    def apply_amendment(self, proposal: AmendmentProposal) -> AmendmentResult:
        """Validate and apply an AmendmentProposal against the active Constitution.

        Validation order:
        1. Verify `proposer_role` exists in `constitution.roles`.
        2. Locate existing rule matching `target_rule_id`.
        3. Verify operator immutability (`immutable_by_operator: true` blocks `org_administrator`
           and any role not explicitly owning or permitted to amend higher levels).
        4. Verify target rule's current `level` is in `role.can_amend_levels`.
        5. Prevent privilege escalation: verify `proposal.updated_rule.level` is also in `role.can_amend_levels`,
           and that an operator (`org_administrator`) cannot flip `immutable_by_operator` on a protected rule.
        6. Verify quorum signatures: `len(set(non_empty_signatures)) >= role.requires_quorum_signatures`.
        7. On success: bump patch version (`1.0.0` -> `1.0.1`), update in-memory rule, update `last_updated`,
           and log an `AMENDMENT` record to the canonical hash-chained audit ledger.
        """
        start_ns = time.perf_counter_ns()

        # 1. Verify proposer_role exists
        role_spec = self.constitution.roles.get(proposal.proposer_role)
        if role_spec is None:
            raise UnauthorizedAmendmentError(
                f"Unknown proposer_role '{proposal.proposer_role}'."
            )

        # 2. Locate target rule
        rule_idx = self._find_rule_index(proposal.target_rule_id)
        if rule_idx is None:
            raise UnauthorizedAmendmentError(
                f"Target rule '{proposal.target_rule_id}' does not exist in active constitution."
            )
        existing_rule: Rule = self.constitution.rules[rule_idx]

        # 3. Check operator immutability constraint
        if existing_rule.immutable_by_operator and proposal.proposer_role == "org_administrator":
            raise UnauthorizedAmendmentError(
                f"Rule '{existing_rule.id}' is marked immutable_by_operator=True and cannot be amended by 'org_administrator'."
            )

        # 4. Verify existing rule's level is in role.can_amend_levels
        if existing_rule.level not in role_spec.can_amend_levels:
            raise UnauthorizedAmendmentError(
                f"Role '{proposal.proposer_role}' (allowed levels {role_spec.can_amend_levels}) "
                f"is not authorized to amend Level {existing_rule.level} rule '{existing_rule.id}'."
            )

        # 5. Prevent privilege escalation (changing rule level to an unauthorized level or ID mismatch)
        if proposal.updated_rule.id != proposal.target_rule_id:
            raise UnauthorizedAmendmentError(
                f"Amendment updated_rule.id ('{proposal.updated_rule.id}') must match target_rule_id ('{proposal.target_rule_id}')."
            )

        if proposal.updated_rule.level not in role_spec.can_amend_levels:
            raise UnauthorizedAmendmentError(
                f"Privilege escalation blocked: Role '{proposal.proposer_role}' cannot move rule "
                f"'{existing_rule.id}' to unauthorized Level {proposal.updated_rule.level}."
            )

        # 6. Verify distinct non-empty signatures meet quorum requirement
        distinct_signatures = {sig.strip() for sig in proposal.signatures if sig and sig.strip()}
        if len(distinct_signatures) < role_spec.requires_quorum_signatures:
            raise UnauthorizedAmendmentError(
                f"Quorum check failed for role '{proposal.proposer_role}': requires at least "
                f"{role_spec.requires_quorum_signatures} distinct signatures, got {len(distinct_signatures)}."
            )

        # 7. Apply amendment, bump patch version, and record in tamper-evident audit ledger
        previous_version = self.constitution.version
        new_version = bump_patch_version(previous_version)

        updated_rules = list(self.constitution.rules)
        updated_rules[rule_idx] = proposal.updated_rule
        self.constitution.rules = updated_rules
        self.constitution.version = new_version
        self.constitution.last_updated = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

        elapsed_ns = time.perf_counter_ns() - start_ns
        latency_ms = round(elapsed_ns / 1_000_000.0, 6)

        audit_record = self.audit_ledger.append_record(
            event_type="AMENDMENT",
            request_id=f"amend-{uuid.uuid4().hex[:12]}",
            policy_version=new_version,
            decision="AMEND",
            winning_rule_id=proposal.target_rule_id,
            triggered_rule_ids=[proposal.target_rule_id],
            escalated_to=None,
            latency_ms=latency_ms,
            metadata={
                "proposer_role": proposal.proposer_role,
                "previous_version": previous_version,
                "new_version": new_version,
                "signatures": sorted(distinct_signatures),
                "reason": proposal.reason,
            },
        )

        return AmendmentResult(
            status="AMENDED",
            previous_version=previous_version,
            new_version=new_version,
            target_rule_id=proposal.target_rule_id,
            proposer_role=proposal.proposer_role,
            quorum_signatures_count=len(distinct_signatures),
            audit_entry_hash=audit_record.entry_hash,
        )
