"""The 5-Check Deterministic Validation Engine for Sarcastic Fringehead (v0.1 — Phase 2).

Executes five modular, deterministic checks without calling an external LLM:
1. Format & Completeness Check
2. Safe AST Symbolic Math & Calculation Check (`verify_calculations` — zero `eval()`)
3. Factual Grounding Check (`verify_facts` against `trusted_facts`)
4. Relevance & Internal Consistency Check (`verify_consistency`)
5. Confidence & Uncertainty Aggregation (`ValidationReport` + context injection)
"""

from __future__ import annotations

import ast
import json
import math
import re
import time
from typing import Any, Dict, List, Optional, Tuple

from .models import EvaluationRequest, ValidationReport, ValidationStatusType

# Matches inline arithmetic equations such as:
# "125 * 4 = 500", "10 + 20 - 5 = 25", "(40 * 1.15) = 46", "-5 + 12 = 7"
INLINE_EQUATION_PATTERN = re.compile(
    r"(?<![A-Za-z0-9_])"
    r"((?:\(\s*)*[-+]?\d+(?:\.\d+)?(?:\s*\))*"
    r"(?:\s*(?:\*\*|[+\-*/])\s*(?:\(\s*)*[-+]?\d+(?:\.\d+)?(?:\s*\))*)+)"
    r"\s*=\s*"
    r"([-+]?\d+(?:\.\d+)?)"
    r"(?![A-Za-z0-9_.])"
)

# Detects suspicious code-execution / injection tokens in candidate expressions or text
UNSAFE_CODE_PATTERNS = re.compile(
    r"(__import__|eval\s*\(|exec\s*\(|compile\s*\(|open\s*\(|getattr\s*\(|"
    r"setattr\s*\(|globals\s*\(|locals\s*\(|os\.system|subprocess|builtins|__subclasses__)",
    re.IGNORECASE,
)

REFUSAL_PHRASES = (
    "i cannot fulfill",
    "i cannot assist",
    "i'm unable to",
    "i am unable to",
    "access denied",
    "cannot disclose",
    "cannot share",
    "not authorized to provide",
    "policy prohibits",
)


class UnsafeMathExpressionError(ValueError):
    """Raised when an expression contains any non-whitelisted AST node or unsafe operation."""


class SafeArithmeticEvaluator(ast.NodeVisitor):
    """Deterministic AST evaluator permitting strictly whitelisted arithmetic nodes.

    Allowed AST nodes:
    - `ast.Expression`
    - `ast.BinOp` with `(ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Pow)`
    - `ast.UnaryOp` with `(ast.USub, ast.UAdd)`
    - `ast.Constant` (int/float only, excluding bool)
    - `ast.Num` (Python <3.8 legacy compatibility)

    Any `ast.Call`, `ast.Name`, `ast.Attribute`, `ast.Subscript`, `ast.Lambda`, etc.
    immediately raises `UnsafeMathExpressionError` without executing anything.
    """

    MAX_AST_NODES = 64
    MAX_EXPONENT = 1000.0

    def __init__(self) -> None:
        self._node_count = 0

    def evaluate(self, expr: str) -> float:
        self._node_count = 0
        cleaned = expr.strip()
        if not cleaned or len(cleaned) > 512:
            raise UnsafeMathExpressionError("Empty or excessively long arithmetic expression.")
        try:
            tree = ast.parse(cleaned, mode="eval")
        except SyntaxError as exc:
            raise UnsafeMathExpressionError(f"Syntax error in arithmetic expression: {exc}") from exc
        return float(self.visit(tree))

    def visit(self, node: ast.AST) -> Any:
        self._node_count += 1
        if self._node_count > self.MAX_AST_NODES:
            raise UnsafeMathExpressionError("Expression exceeded maximum allowed AST complexity.")
        return super().visit(node)

    def visit_Expression(self, node: ast.Expression) -> float:
        return float(self.visit(node.body))

    def visit_Constant(self, node: ast.Constant) -> float:
        val = node.value
        if isinstance(val, bool) or not isinstance(val, (int, float)):
            raise UnsafeMathExpressionError(f"Disallowed constant type: {type(val).__name__}")
        return float(val)

    def visit_Num(self, node: Any) -> float:  # pragma: no cover - legacy AST node
        val = node.n
        if isinstance(val, bool) or not isinstance(val, (int, float)):
            raise UnsafeMathExpressionError(f"Disallowed numeric literal: {type(val).__name__}")
        return float(val)

    def visit_UnaryOp(self, node: ast.UnaryOp) -> float:
        operand = float(self.visit(node.operand))
        if isinstance(node.op, ast.USub):
            return -operand
        if isinstance(node.op, ast.UAdd):
            return +operand
        raise UnsafeMathExpressionError(f"Disallowed unary operator: {type(node.op).__name__}")

    def visit_BinOp(self, node: ast.BinOp) -> float:
        left = float(self.visit(node.left))
        right = float(self.visit(node.right))

        if isinstance(node.op, ast.Add):
            return left + right
        if isinstance(node.op, ast.Sub):
            return left - right
        if isinstance(node.op, ast.Mult):
            return left * right
        if isinstance(node.op, ast.Div):
            if abs(right) < 1e-15:
                raise UnsafeMathExpressionError("Division by zero in arithmetic expression.")
            return left / right
        if isinstance(node.op, ast.Pow):
            if abs(right) > self.MAX_EXPONENT:
                raise UnsafeMathExpressionError("Exponent magnitude exceeds safe limit.")
            return math.pow(left, right)

        raise UnsafeMathExpressionError(f"Disallowed binary operator: {type(node.op).__name__}")

    def generic_visit(self, node: ast.AST) -> Any:
        raise UnsafeMathExpressionError(
            f"Forbidden AST node '{type(node).__name__}' rejected by SafeArithmeticEvaluator."
        )


def safe_eval_math_expr(expr: str) -> float:
    """Evaluate a pure arithmetic expression string safely via `SafeArithmeticEvaluator`."""
    return SafeArithmeticEvaluator().evaluate(expr)


class ValidationEngine:
    """5-Check Deterministic Validation Engine for candidate AI responses."""

    def __init__(
        self,
        *,
        max_query_length: int = 32_768,
        max_response_length: int = 65_536,
        float_tolerance: float = 1e-6,
    ) -> None:
        self.max_query_length = max_query_length
        self.max_response_length = max_response_length
        self.float_tolerance = float_tolerance
        self._math_evaluator = SafeArithmeticEvaluator()

    def check_format_and_completeness(
        self,
        query: str,
        response_text: str,
        *,
        require_json: bool = False,
        required_json_keys: Optional[List[str]] = None,
    ) -> Tuple[bool, List[str]]:
        """Stage 1: Verify non-empty query/response, length bounds, and optional JSON schema validity."""
        issues: List[str] = []
        if not isinstance(query, str) or not query.strip():
            issues.append("EMPTY_QUERY")
        elif len(query) > self.max_query_length:
            issues.append("QUERY_MAX_LENGTH_EXCEEDED")

        if not isinstance(response_text, str) or not response_text.strip():
            issues.append("EMPTY_RESPONSE")
        elif len(response_text) > self.max_response_length:
            issues.append("RESPONSE_MAX_LENGTH_EXCEEDED")

        if require_json and response_text.strip():
            try:
                parsed = json.loads(response_text)
                if not isinstance(parsed, dict):
                    issues.append("JSON_ROOT_NOT_OBJECT")
                elif required_json_keys:
                    missing = [k for k in required_json_keys if k not in parsed]
                    if missing:
                        issues.append(f"JSON_MISSING_KEYS:{','.join(missing)}")
            except ValueError:
                issues.append("INVALID_JSON_SYNTAX")

        return len(issues) == 0, issues

    def verify_calculations(
        self, response_text: str
    ) -> Tuple[bool, List[str], List[str]]:
        """Stage 2: Extract inline equations and verify arithmetic via safe AST whitelist.

        Also scans for any unsafe expression injection attempts (e.g., `__import__('os').system('ls')`)
        and rejects/records them without executing any code.

        Returns:
            Tuple[bool, List[str], List[str]]:
                (math_check_passed, failed_equations, rejected_unsafe_expressions)
        """
        failed_equations: List[str] = []
        rejected_unsafe: List[str] = []

        if not response_text:
            return True, failed_equations, rejected_unsafe

        # Check if response contains any LHS = RHS candidate with unsafe code patterns
        for raw_segment in re.finditer(r"([^\n=;]{1,160})=\s*([-+]?\d+(?:\.\d+)?)", response_text):
            lhs_candidate = raw_segment.group(1).strip()
            if UNSAFE_CODE_PATTERNS.search(lhs_candidate):
                rejected_unsafe.append(lhs_candidate)

        if UNSAFE_CODE_PATTERNS.search(response_text):
            for match in UNSAFE_CODE_PATTERNS.finditer(response_text):
                snippet = match.group(0)
                if snippet not in rejected_unsafe:
                    rejected_unsafe.append(snippet)

        # Evaluate all mathematical equations matching INLINE_EQUATION_PATTERN
        for match in INLINE_EQUATION_PATTERN.finditer(response_text):
            lhs_str = match.group(1).strip()
            rhs_str = match.group(2).strip()
            full_eq = f"{lhs_str} = {rhs_str}"
            try:
                computed_val = self._math_evaluator.evaluate(lhs_str)
                expected_val = float(rhs_str)
                if not math.isclose(
                    computed_val,
                    expected_val,
                    rel_tol=self.float_tolerance,
                    abs_tol=self.float_tolerance,
                ):
                    failed_equations.append(
                        f"{full_eq} (computed {computed_val:g} != stated {expected_val:g})"
                    )
            except UnsafeMathExpressionError as exc:
                rejected_unsafe.append(f"{lhs_str} ({exc})")

        math_check_passed = len(failed_equations) == 0
        return math_check_passed, failed_equations, rejected_unsafe

    @staticmethod
    def _values_equal(left: Any, right: Any) -> bool:
        if isinstance(left, bool) != isinstance(right, bool):
            return False
        if isinstance(left, (int, float)) and isinstance(right, (int, float)):
            return math.isclose(float(left), float(right), rel_tol=1e-6, abs_tol=1e-6)
        return left == right

    def verify_facts(
        self,
        structured_claims: List[Dict[str, Any]],
        trusted_facts: List[Dict[str, Any]],
    ) -> Tuple[int, List[str]]:
        """Stage 3: Compare each item in `structured_claims` against `trusted_facts`.

        Supports two common trusted_fact schemas:
        1. Triples: `{"entity": "Order_101", "attribute": "status", "value": "shipped", "source_id": "doc_1"}`
        2. Entity records: `{"entity": "Order_101", "source_id": "doc_1", "refund_eligible": False, ...}`

        Increments `unverified_factual_claims` if:
        - A claim cites a `source_id` that does not exist in `trusted_facts`.
        - A claim references an `(entity, attribute)` not backed by `trusted_facts` (when `trusted_facts` is provided).
        - A claim states a `value` that contradicts `trusted_facts`.
        """
        unverified_count = 0
        details: List[str] = []

        if not structured_claims:
            return 0, details

        known_sources = {
            str(tf["source_id"])
            for tf in trusted_facts
            if isinstance(tf, dict) and tf.get("source_id") is not None
        }

        # Index trusted facts by (entity, attribute) -> list of (value, source_id)
        fact_index: Dict[Tuple[str, str], List[Tuple[Any, Optional[str]]]] = {}
        for tf in trusted_facts:
            if not isinstance(tf, dict):
                continue
            entity = str(tf.get("entity") or tf.get("id") or "")
            src_id = str(tf["source_id"]) if tf.get("source_id") is not None else None
            if not entity:
                continue

            if "attribute" in tf and "value" in tf:
                key = (entity, str(tf["attribute"]))
                fact_index.setdefault(key, []).append((tf["value"], src_id))
            else:
                for k, v in tf.items():
                    if k in ("entity", "id", "source_id"):
                        continue
                    key = (entity, str(k))
                    fact_index.setdefault(key, []).append((v, src_id))

        for idx, claim in enumerate(structured_claims):
            if not isinstance(claim, dict):
                unverified_count += 1
                details.append(f"claim[{idx}]: malformed non-dict claim")
                continue

            entity = str(claim.get("entity") or claim.get("id") or "")
            attribute = str(claim.get("attribute") or "")
            claimed_value = claim.get("value")
            claimed_source = (
                str(claim["source_id"]) if claim.get("source_id") is not None else None
            )

            # Check missing source_id if claim specifies one (or if trusted_facts has source_ids)
            if claimed_source is not None and known_sources and claimed_source not in known_sources:
                unverified_count += 1
                details.append(
                    f"claim[{idx}] ({entity}.{attribute}): cites unknown source_id '{claimed_source}'"
                )
                continue

            if entity and attribute:
                key = (entity, attribute)
                matching_facts = fact_index.get(key)
                if not matching_facts:
                    unverified_count += 1
                    details.append(
                        f"claim[{idx}] ({entity}.{attribute}={claimed_value!r}): no matching trusted fact found"
                    )
                    continue

                # Check if at least one trusted fact matches both value and (if provided) source_id
                verified = False
                for trusted_val, trusted_src in matching_facts:
                    source_ok = (
                        claimed_source is None
                        or trusted_src is None
                        or claimed_source == trusted_src
                    )
                    if source_ok and self._values_equal(claimed_value, trusted_val):
                        verified = True
                        break

                if not verified:
                    trusted_vals = [tv for tv, _ in matching_facts]
                    unverified_count += 1
                    details.append(
                        f"claim[{idx}] ({entity}.{attribute}): claimed {claimed_value!r} contradicts trusted {trusted_vals!r}"
                    )
            else:
                # Dict claim with direct entity fields: {"entity": "Order_101", "refund_eligible": True}
                if not entity:
                    unverified_count += 1
                    details.append(f"claim[{idx}]: missing 'entity' identifier")
                    continue
                attr_keys = [
                    k for k in claim.keys() if k not in ("entity", "id", "source_id")
                ]
                if not attr_keys:
                    unverified_count += 1
                    details.append(f"claim[{idx}] ({entity}): no attribute/value specified")
                    continue
                for attr_k in attr_keys:
                    c_val = claim[attr_k]
                    matching_facts = fact_index.get((entity, str(attr_k)))
                    if not matching_facts:
                        unverified_count += 1
                        details.append(
                            f"claim[{idx}] ({entity}.{attr_k}={c_val!r}): no matching trusted fact"
                        )
                    elif not any(self._values_equal(c_val, tv) for tv, _ in matching_facts):
                        trusted_vals = [tv for tv, _ in matching_facts]
                        unverified_count += 1
                        details.append(
                            f"claim[{idx}] ({entity}.{attr_k}): claimed {c_val!r} contradicts trusted {trusted_vals!r}"
                        )

        return unverified_count, details

    def verify_consistency(
        self,
        response_text: str,
        structured_claims: List[Dict[str, Any]],
        *,
        restricted_values: Optional[List[str]] = None,
    ) -> Tuple[bool, List[str]]:
        """Stage 4: Check internal consistency across structured claims and refusal leakages."""
        issues: List[str] = []

        # 1. Check self-contradictory structured_claims within the same response
        seen_claims: Dict[Tuple[str, str], Any] = {}
        for idx, claim in enumerate(structured_claims):
            if not isinstance(claim, dict):
                continue
            entity = str(claim.get("entity") or claim.get("id") or "")
            if not entity:
                continue

            if "attribute" in claim and "value" in claim:
                pairs = [(str(claim["attribute"]), claim["value"])]
            else:
                pairs = [
                    (str(k), v)
                    for k, v in claim.items()
                    if k not in ("entity", "id", "source_id")
                ]

            for attr, val in pairs:
                key = (entity, attr)
                if key in seen_claims:
                    prev_val = seen_claims[key]
                    if not self._values_equal(prev_val, val):
                        issues.append(
                            f"SELF_CONTRADICTION:{entity}.{attr} stated as both {prev_val!r} and {val!r}"
                        )
                else:
                    seen_claims[key] = val

        # 2. Check refusal message simultaneously leaking restricted values or sensitive claims
        lower_resp = (response_text or "").lower()
        is_refusal = any(phrase in lower_resp for phrase in REFUSAL_PHRASES)
        if is_refusal and restricted_values:
            for secret in restricted_values:
                if secret and str(secret).lower() in lower_resp:
                    issues.append("REFUSAL_PAYLOAD_LEAK")
                    break

        return len(issues) == 0, issues

    def validate(
        self,
        query: str,
        response_text: str,
        trusted_facts: Optional[List[Dict[str, Any]]] = None,
        structured_claims: Optional[List[Dict[str, Any]]] = None,
        *,
        require_json: bool = False,
        required_json_keys: Optional[List[str]] = None,
        restricted_values: Optional[List[str]] = None,
    ) -> ValidationReport:
        """Execute all 5 deterministic validation checks and return a ValidationReport."""
        start_ns = time.perf_counter_ns()
        trusted_facts_list = trusted_facts or []
        structured_claims_list = structured_claims or []

        failed_checks: List[str] = []

        # 1. Format & Completeness Check
        format_ok, format_issues = self.check_format_and_completeness(
            query=query,
            response_text=response_text,
            require_json=require_json,
            required_json_keys=required_json_keys,
        )
        if not format_ok:
            failed_checks.extend(format_issues)

        # 2. Deterministic Math & Calculation Check
        math_ok, failed_eqs, rejected_unsafe = self.verify_calculations(response_text)
        if not math_ok:
            failed_checks.append("MATH_CALCULATION_MISMATCH")

        # 3. Factual Grounding Check
        unverified_count, claim_issues = self.verify_facts(
            structured_claims=structured_claims_list,
            trusted_facts=trusted_facts_list,
        )
        if unverified_count > 0:
            failed_checks.append("UNVERIFIED_FACTUAL_CLAIMS")

        # 4. Relevance & Internal Consistency Check
        consistency_ok, consistency_issues = self.verify_consistency(
            response_text=response_text,
            structured_claims=structured_claims_list,
            restricted_values=restricted_values,
        )
        if not consistency_ok:
            failed_checks.append("INTERNAL_CONSISTENCY_FAILURE")

        # 5. Confidence & Uncertainty Aggregation
        if not math_ok or unverified_count > 0 or not consistency_ok:
            overall_status: ValidationStatusType = "REJECT"
            confidence_score = 0.0
        elif not format_ok or rejected_unsafe:
            overall_status = "RECHECK"
            confidence_score = 0.5
        else:
            overall_status = "PASS"
            confidence_score = 1.0

        elapsed_ns = time.perf_counter_ns() - start_ns
        latency_ms = round(elapsed_ns / 1_000_000.0, 6)

        return ValidationReport(
            overall_status=overall_status,
            format_check_passed=format_ok,
            math_check_passed=math_ok,
            failed_equations=failed_eqs,
            rejected_unsafe_expressions=rejected_unsafe,
            unverified_factual_claims=unverified_count,
            unverified_claim_details=claim_issues,
            consistency_passed=consistency_ok,
            consistency_issues=consistency_issues,
            confidence_score=confidence_score,
            failed_checks=failed_checks,
            validation_latency_ms=latency_ms,
        )

    @staticmethod
    def inject_into_request(
        request: EvaluationRequest, report: ValidationReport
    ) -> EvaluationRequest:
        """Inject `validation.*` signals into both `request.validation` and `request.context['validation']`."""
        validation_payload = {
            "overall_status": report.overall_status,
            "format_check_passed": report.format_check_passed,
            "math_check_passed": report.math_check_passed,
            "failed_equations": list(report.failed_equations),
            "rejected_unsafe_expressions": list(report.rejected_unsafe_expressions),
            "unverified_factual_claims": report.unverified_factual_claims,
            "consistency_passed": report.consistency_passed,
            "confidence_score": report.confidence_score,
            "failed_checks": list(report.failed_checks),
            "validation_latency_ms": report.validation_latency_ms,
        }
        request.validation = validation_payload
        request.context["validation"] = validation_payload
        return request
