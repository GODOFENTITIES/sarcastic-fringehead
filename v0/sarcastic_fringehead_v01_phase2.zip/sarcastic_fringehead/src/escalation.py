"""Vendor-Agnostic Pluggable Escalation Layer for Sarcastic Fringehead (v0.1 — Phase 2).

Defines:
- `EscalationProvider` (typing.Protocol)
- `LocalHeuristicEscalationProvider` (zero external dependencies)
- `EscalationRouter` (plugin registry + `asyncio.wait_for()` timeout enforcement +
  confidence threshold guardrail + strict `BLOCK` authority boundary)
"""

from __future__ import annotations

import asyncio
import time
from typing import Dict, Optional, Protocol, runtime_checkable

from .audit import AuditLedger
from .models import (
    ActionType,
    EscalationResolution,
    EscalationResult,
    EvaluationDecision,
    EvaluationRequest,
)


@runtime_checkable
class EscalationProvider(Protocol):
    """Vendor-agnostic protocol for pluggable secondary risk evaluators."""

    name: str

    async def evaluate(self, request: EvaluationRequest, rule_id: str) -> EscalationResult:
        """Asynchronously evaluate an escalated REVIEW request and return structured advisory signal."""
        ...


class LocalHeuristicEscalationProvider:
    """Built-in local heuristic escalation provider with zero external dependencies.

    Inspects risk signals in the request context (`classifier`, `context`, `tool`, `session`,
    `validation`) and produces a structured `EscalationResult`.
    """

    def __init__(
        self,
        name: str = "local_heuristic_provider",
        high_confidence_threshold: float = 0.85,
    ) -> None:
        self.name = name
        self.high_confidence_threshold = high_confidence_threshold

    async def evaluate(self, request: EvaluationRequest, rule_id: str) -> EscalationResult:
        start_ns = time.perf_counter_ns()

        hazard = request.classifier.get("hazard_category")
        uncertainty = float(request.classifier.get("uncertainty_score", 0.0) or 0.0)
        untrusted = bool(request.context.get("contains_untrusted_retrieval", False))
        explicit_confirm = bool(request.session.get("explicit_user_confirmation", False))
        amount_usd = float((request.tool.get("args") or {}).get("amount_usd", 0.0) or 0.0)

        if hazard in ("severe_harm", "cyber_exploit", "credential_harvesting"):
            action: ActionType = "BLOCK"
            confidence = 0.96
            risk_label = "HIGH_RISK_HAZARD_SIGNAL"
        elif untrusted and not explicit_confirm:
            action = "REVIEW"
            confidence = 0.90
            risk_label = "UNTRUSTED_RETRIEVAL_QUARANTINE"
        elif amount_usd > 50.0:
            action = "REVIEW"
            confidence = 0.88
            risk_label = "MONETARY_CAP_SUPERVISOR_REQUIRED"
        elif uncertainty > 0.50:
            action = "REVIEW"
            confidence = 0.60
            risk_label = "ELEVATED_CLASSIFIER_UNCERTAINTY"
        elif explicit_confirm and not untrusted and uncertainty <= 0.15:
            action = "ALLOW"
            confidence = 0.91
            risk_label = "VERIFIED_LOW_RISK_CONTEXT"
        else:
            action = "REVIEW"
            confidence = 0.70
            risk_label = "DEFAULT_CONSERVATIVE_REVIEW"

        elapsed_ms = round((time.perf_counter_ns() - start_ns) / 1_000_000.0, 6)
        return EscalationResult(
            provider_name=self.name,
            recommended_action=action,
            confidence=confidence,
            risk_label=risk_label,
            latency_ms=elapsed_ms,
        )


class EscalationRouter:
    """Plugin registry and timeout-safe async executor for REVIEW escalations.

    Strict Authority & Safety Rules:
    1. A plugin can NEVER downgrade or override a deterministic `BLOCK` decision.
    2. Calls are bounded by `asyncio.wait_for(..., timeout=timeout_ms / 1000.0)`.
    3. On `asyncio.TimeoutError` or any exception, falls back deterministically to
       `on_timeout_action` (default `"REVIEW"`) with `reason="ESCALATION_TIMEOUT_OR_ERROR"`
       and logs the event to the SHA-256 `AuditLedger`.
    4. If `result.confidence < confidence_threshold` (default `0.85`), keeps decision as
       `"REVIEW"` (`reason="LOW_CONFIDENCE_GUARDRAIL"`).
    """

    def __init__(
        self,
        *,
        default_timeout_ms: float = 150.0,
        confidence_threshold: float = 0.85,
        on_timeout_action: ActionType = "REVIEW",
        audit_ledger: Optional[AuditLedger] = None,
    ) -> None:
        self.default_timeout_ms = default_timeout_ms
        self.confidence_threshold = confidence_threshold
        self.on_timeout_action: ActionType = on_timeout_action
        self.audit_ledger = audit_ledger
        self._providers: Dict[str, EscalationProvider] = {}

        # Register built-in offline heuristic fallback for default targets
        default_provider = LocalHeuristicEscalationProvider(
            high_confidence_threshold=confidence_threshold
        )
        self.register("secondary_risk_evaluator", default_provider)
        self.register("human_support_supervisor", default_provider)
        self.register("jev_decision_layer", default_provider)

    def register(self, target_name: str, provider: EscalationProvider) -> None:
        """Register or replace an EscalationProvider plugin for `target_name`."""
        self._providers[target_name] = provider

    def get_provider(self, target_name: str) -> Optional[EscalationProvider]:
        """Retrieve registered EscalationProvider for `target_name`."""
        return self._providers.get(target_name)

    async def resolve(
        self,
        request: EvaluationRequest,
        decision: EvaluationDecision,
        *,
        timeout_ms: Optional[float] = None,
        confidence_threshold: Optional[float] = None,
        policy_version: str = "1.0.0",
    ) -> EscalationResolution:
        """Execute registered escalation provider if and only if decision is REVIEW."""
        start_ns = time.perf_counter_ns()
        effective_timeout_ms = (
            timeout_ms if timeout_ms is not None else self.default_timeout_ms
        )
        effective_threshold = (
            confidence_threshold
            if confidence_threshold is not None
            else self.confidence_threshold
        )
        target_name = decision.escalated_to or "secondary_risk_evaluator"
        rule_id = decision.winning_rule_id or "UNSPECIFIED_RULE"

        # 1. Authority boundary: NEVER allow escalation to override a deterministic BLOCK
        if decision.decision == "BLOCK":
            elapsed_ms = round((time.perf_counter_ns() - start_ns) / 1_000_000.0, 6)
            return EscalationResolution(
                initial_decision="BLOCK",
                final_decision="BLOCK",
                target_provider=target_name,
                provider_result=None,
                resolution_reason="AUTHORITY_BOUNDARY_DETERMINISTIC_BLOCK_IMMUTABLE",
                timed_out_or_errored=False,
                low_confidence_fallback=False,
                authority_boundary_enforced=True,
                escalation_latency_ms=elapsed_ms,
            )

        # Only REVIEW decisions are eligible for escalation resolution
        if decision.decision != "REVIEW":
            elapsed_ms = round((time.perf_counter_ns() - start_ns) / 1_000_000.0, 6)
            return EscalationResolution(
                initial_decision=decision.decision,
                final_decision=decision.decision,
                target_provider=target_name,
                provider_result=None,
                resolution_reason="NO_ESCALATION_REQUIRED",
                escalation_latency_ms=elapsed_ms,
            )

        provider = self._providers.get(target_name)
        if provider is None:
            elapsed_ms = round((time.perf_counter_ns() - start_ns) / 1_000_000.0, 6)
            return self._record_and_build_resolution(
                request=request,
                decision=decision,
                target_name=target_name,
                final_decision=self.on_timeout_action,
                provider_result=None,
                reason="ESCALATION_PROVIDER_NOT_REGISTERED",
                timed_out_or_errored=True,
                low_confidence=False,
                elapsed_ms=elapsed_ms,
                policy_version=policy_version,
            )

        # 2. Execute plugin inside asyncio.wait_for()
        try:
            provider_result = await asyncio.wait_for(
                provider.evaluate(request, rule_id),
                timeout=effective_timeout_ms / 1000.0,
            )
        except (asyncio.TimeoutError, Exception) as exc:
            elapsed_ms = round((time.perf_counter_ns() - start_ns) / 1_000_000.0, 6)
            fallback_result = EscalationResult(
                provider_name= getattr(provider, "name", target_name),
                recommended_action=self.on_timeout_action,
                confidence=0.0,
                risk_label="ESCALATION_TIMEOUT_OR_ERROR",
                latency_ms=elapsed_ms,
                reason=f"ESCALATION_TIMEOUT_OR_ERROR:{type(exc).__name__}",
            )
            return self._record_and_build_resolution(
                request=request,
                decision=decision,
                target_name=target_name,
                final_decision=self.on_timeout_action,
                provider_result=fallback_result,
                reason="ESCALATION_TIMEOUT_OR_ERROR",
                timed_out_or_errored=True,
                low_confidence=False,
                elapsed_ms=elapsed_ms,
                policy_version=policy_version,
            )

        elapsed_ms = round((time.perf_counter_ns() - start_ns) / 1_000_000.0, 6)

        # 3. Low-confidence guardrail: never auto-allow or adopt low-confidence predictions
        if provider_result.confidence < effective_threshold:
            return self._record_and_build_resolution(
                request=request,
                decision=decision,
                target_name=target_name,
                final_decision="REVIEW",
                provider_result=provider_result,
                reason="LOW_CONFIDENCE_GUARDRAIL",
                timed_out_or_errored=False,
                low_confidence=True,
                elapsed_ms=elapsed_ms,
                policy_version=policy_version,
            )

        # 4. High-confidence advisory resolution on a REVIEW case
        final_decision: ActionType = provider_result.recommended_action
        return self._record_and_build_resolution(
            request=request,
            decision=decision,
            target_name=target_name,
            final_decision=final_decision,
            provider_result=provider_result,
            reason="HIGH_CONFIDENCE_PROVIDER_RESOLUTION",
            timed_out_or_errored=False,
            low_confidence=False,
            elapsed_ms=elapsed_ms,
            policy_version=policy_version,
        )

    def _record_and_build_resolution(
        self,
        *,
        request: EvaluationRequest,
        decision: EvaluationDecision,
        target_name: str,
        final_decision: ActionType,
        provider_result: Optional[EscalationResult],
        reason: str,
        timed_out_or_errored: bool,
        low_confidence: bool,
        elapsed_ms: float,
        policy_version: str,
    ) -> EscalationResolution:
        audit_hash: Optional[str] = None
        if self.audit_ledger is not None:
            record = self.audit_ledger.append_record(
                event_type="EVALUATION",
                request_id=request.request_id,
                policy_version=policy_version,
                decision=final_decision,
                winning_rule_id=decision.winning_rule_id,
                triggered_rule_ids=list(decision.matched_rule_ids),
                escalated_to=target_name,
                latency_ms=elapsed_ms,
                metadata={
                    "phase": "ESCALATION_RESOLUTION",
                    "initial_decision": decision.decision,
                    "final_decision": final_decision,
                    "resolution_reason": reason,
                    "timed_out_or_errored": timed_out_or_errored,
                    "low_confidence_fallback": low_confidence,
                    "provider_name": provider_result.provider_name if provider_result else None,
                    "provider_confidence": provider_result.confidence if provider_result else 0.0,
                    "provider_risk_label": provider_result.risk_label if provider_result else None,
                },
            )
            audit_hash = record.entry_hash
            decision.audit_entry_hash = record.entry_hash

        decision.decision = final_decision
        resolution = EscalationResolution(
            initial_decision="REVIEW",
            final_decision=final_decision,
            target_provider=target_name,
            provider_result=provider_result,
            resolution_reason=reason,
            timed_out_or_errored=timed_out_or_errored,
            low_confidence_fallback=low_confidence,
            authority_boundary_enforced=False,
            escalation_latency_ms=elapsed_ms,
            audit_entry_hash=audit_hash,
        )
        decision.escalation_resolution = resolution
        return resolution
