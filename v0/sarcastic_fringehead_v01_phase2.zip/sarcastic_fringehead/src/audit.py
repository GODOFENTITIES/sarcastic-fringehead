"""Tamper-Evident Canonical SHA-256 Hash-Chained Audit Ledger.

Logs every evaluation and constitutional amendment decision using canonical JSON
serialization (`sort_keys=True, separators=(",", ":")`) and `hashlib.sha256`.
"""

from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional, Tuple, Union

from .models import ActionType, StrictBaseModel

GENESIS_HASH: str = "0" * 64


def canonical_json(data: Dict[str, Any]) -> str:
    """Serialize dictionary into deterministic canonical JSON string."""
    return json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def compute_sha256(payload: str) -> str:
    """Compute hex-encoded SHA-256 digest of a canonical string payload."""
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


class AuditRecord(StrictBaseModel):
    """Single immutable entry in the tamper-evident hash chain."""

    sequence_id: int
    timestamp: str
    event_type: Literal["EVALUATION", "AMENDMENT"]
    request_id: str
    policy_version: str
    decision: str
    winning_rule_id: Optional[str] = None
    triggered_rule_ids: List[str]
    escalated_to: Optional[str] = None
    latency_ms: float
    metadata: Dict[str, Any] = {}
    previous_hash: str
    entry_hash: str

    def payload_without_entry_hash(self) -> Dict[str, Any]:
        """Return dictionary representation excluding `entry_hash` for canonical hashing."""
        raw = self.model_dump()
        raw.pop("entry_hash", None)
        return raw

    def compute_expected_hash(self) -> str:
        """Compute canonical SHA-256 hash over all fields except `entry_hash`."""
        return compute_sha256(canonical_json(self.payload_without_entry_hash()))


class AuditLedger:
    """Append-only SHA-256 hash-chained ledger with optional JSONL persistence."""

    def __init__(self, persistence_path: Optional[Union[str, Path]] = None) -> None:
        self.records: List[AuditRecord] = []
        self.persistence_path: Optional[Path] = (
            Path(persistence_path) if persistence_path is not None else None
        )
        if self.persistence_path is not None:
            self.persistence_path.parent.mkdir(parents=True, exist_ok=True)
            if self.persistence_path.exists():
                self._load_from_disk()

    def _load_from_disk(self) -> None:
        """Load existing JSONL audit records if persistence file exists."""
        if not self.persistence_path or not self.persistence_path.exists():
            return
        loaded: List[AuditRecord] = []
        with self.persistence_path.open("r", encoding="utf-8") as fh:
            for line in fh:
                stripped = line.strip()
                if stripped:
                    loaded.append(AuditRecord.model_validate(json.loads(stripped)))
        self.records = loaded

    @property
    def last_hash(self) -> str:
        """Return the entry_hash of the most recent record, or GENESIS_HASH if empty."""
        if not self.records:
            return GENESIS_HASH
        return self.records[-1].entry_hash

    def append_record(
        self,
        *,
        event_type: Literal["EVALUATION", "AMENDMENT"],
        request_id: str,
        policy_version: str,
        decision: str,
        triggered_rule_ids: List[str],
        latency_ms: float,
        winning_rule_id: Optional[str] = None,
        escalated_to: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        timestamp: Optional[str] = None,
    ) -> AuditRecord:
        """Create, hash-chain, append, and optionally persist a new AuditRecord."""
        seq_id = len(self.records)
        ts = timestamp or datetime.now(timezone.utc).isoformat()
        prev_hash = self.last_hash

        unsigned_payload: Dict[str, Any] = {
            "sequence_id": seq_id,
            "timestamp": ts,
            "event_type": event_type,
            "request_id": request_id,
            "policy_version": policy_version,
            "decision": decision,
            "winning_rule_id": winning_rule_id,
            "triggered_rule_ids": list(triggered_rule_ids),
            "escalated_to": escalated_to,
            "latency_ms": round(float(latency_ms), 6),
            "metadata": metadata or {},
            "previous_hash": prev_hash,
        }

        entry_hash = compute_sha256(canonical_json(unsigned_payload))
        record = AuditRecord(
            **unsigned_payload,
            entry_hash=entry_hash,
        )
        self.records.append(record)

        if self.persistence_path is not None:
            with self.persistence_path.open("a", encoding="utf-8") as fh:
                fh.write(canonical_json(record.model_dump()) + "\n")

        return record

    def verify_chain(self) -> Tuple[bool, Optional[int]]:
        """Recompute every hash from genesis and detect any modification, reordering, or deletion.

        Returns:
            Tuple[bool, Optional[int]]: (is_valid, first_tampered_index_or_None)
        """
        expected_prev_hash = GENESIS_HASH

        for idx, record in enumerate(self.records):
            if record.sequence_id != idx:
                return False, idx
            if record.previous_hash != expected_prev_hash:
                return False, idx
            recomputed_hash = record.compute_expected_hash()
            if record.entry_hash != recomputed_hash:
                return False, idx
            expected_prev_hash = record.entry_hash

        return True, None
