# Sarcastic Fringehead (v0.1) — Phase 3 Comparative Benchmark Report

**Dataset:** `benchmarks/dataset_300.json` ($N = 300$ deterministic cases across 6 slices, `random.seed(42)`)  
**Cost Model:** $E[C] = C_d + p \cdot C_m$ where $C_d = 1.0\text{ unit}$ (deterministic check) and $C_m = 25.0\text{ units}$ (secondary evaluator invocation).

## Table 1: Overall Safety vs. Utility Comparison

| Architecture | Violation Rate (FNR ↓) | Violation Recall (TPR ↑) | False-Block Rate (FPR ↓) | Precision (↑) | F1 Score (↑) | Paired Boundary Accuracy (50 Pairs ↑) | Rule Conflict Accuracy (20 Cases ↑) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **Baseline A (`FlatFilter`)** | 50.00% | 35.00% | 50.00% | 58.33% | 0.4375 | 0.00% (0/50) | 0.00% |
| **Baseline B (`AlwaysOnEvaluator`)** | 28.57% | 80.00% | 50.00% | 76.19% | 0.7805 | 0.00% (0/50) | 0.00% |
| **Fringehead C (`Hybrid`)** | **0.00%** | **100.00%** | **0.00%** | **100.00%** | **1.0000** | **100.00% (50/50)** | **100.00%** |

## Table 2: Performance, Escalation & Economic Viability

| Architecture | Escalated Requests ($k / 300$) | Escalation Rate ($p$ ↓) | p50 Latency (ms ↓) | p95 Latency (ms ↓) | p99 Latency (ms ↓) | Expected Governance Cost $E[C]$ (Units ↓) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **Baseline A (`FlatFilter`)** | 0 / 300 | 0.00% | 0.0069 ms | 0.0162 ms | 0.0369 ms | 1.00 units |
| **Baseline B (`AlwaysOnEvaluator`)** | 300 / 300 | 100.00% | 26.3701 ms | 26.9986 ms | 27.1634 ms | 26.00 units (200ms prod eq.) |
| **Fringehead C (`Hybrid`)** | **60 / 300** | **20.00%** | **0.5782 ms** | **1.2682 ms** | **1.7185 ms** | **6.00 units** |

## Table 3: Category-by-Category Exact Decision Accuracy Across the 6 Slices

| Benchmark Slice (Case Count) | Expected Outcome | Baseline A (`FlatFilter`) | Baseline B (`AlwaysOnEvaluator`) | Fringehead C (`Hybrid`) |
| :--- | :---: | :---: | :---: | :---: |
| **1. Clearly Permitted Operations (50)** | `ALLOW` | 100.0% (50/50) | 100.0% (50/50) | **100.0% (50/50)** |
| **2. Hard Level 0 Violations (50)** | `BLOCK` | 40.0% (20/50) | 100.0% (50/50) | **100.0% (50/50)** |
| **3. Matched Benign/Adversarial Pairs (100)** | `50 ALLOW / 50 BLOCK` | 50.0% (50/100) | 50.0% (50/100) | **100.0% (100/100)** |
| **4. Indirect Prompt Injection (40)** | `REVIEW` | 0.0% (0/40) | 100.0% (40/40) | **100.0% (40/40)** |
| **5. Multi-Rule Conflicts & Validation (40)** | `BLOCK` | 0.0% (0/40) | 0.0% (0/40) | **100.0% (40/40)** |
| **6. Org Escalations & Uncertainty (20)** | `REVIEW` | 0.0% (0/20) | 100.0% (20/20) | **100.0% (20/20)** |

## Table 4: Governance Override Resistance & Audit Ledger Integrity Results (20 Operations)

| Stress Test Category | Operations Tested | Expected Outcome | Measured Result | Pass Rate |
| :--- | :---: | :---: | :---: | :---: |
| **1. Unauthorized Operator Amendments (L0 / L1 Rules)** | 10 | 100% Rejected (`UnauthorizedAmendmentError`) | 10 / 10 Rejected | **100.0%** |
| **2. Insufficient Quorum Signature Proposals** | 5 | 100% Rejected (`UnauthorizedAmendmentError`) | 5 / 5 Rejected | **100.0%** |
| **3. Valid Multi-Sig Amendments + SHA-256 Tamper Detection** | 5 | 100% Amended (`1.0.0 -> 1.0.5`) & Tamper Pinpointed | 5 / 5 Verified | **100.0%** |

## Key Findings Summary

- **Zero Constitutional Escapes & Deterministic Math/Fact Catch (`0.00%` Violation Rate):** `FringeheadC_Hybrid` achieved a **0.00%** violation rate across all prohibited cases (including **0.00%** on Level 0 cross-tenant privacy rules and **0.00%** on hallucinated math / factual contradiction checks via `L1-VAL-002`), compared to **50.00%** for `BaselineA_FlatFilter` and **28.57%** for `BaselineB_AlwaysOnEvaluator`.
- **Context-Bound Disambiguation on Matched Boundary Pairs (`100.0%` vs `0.0%`):** On the 50 matched benign-vs-adversarial boundary pairs, `FringeheadC_Hybrid` achieved **100.0% (50/50)** paired accuracy by binding `tool.args.target_user_id` against `session.authenticated_user_id`. `BaselineA_FlatFilter` scored **0.0%** because surface lexical matching erroneously blocked every benign educational twin (`50.0%` overall False-Block Rate).
- **80% Reduction in Secondary Evaluator Escalations & 4.3x Lower Governance Cost:** By resolving `ALLOW` and `BLOCK` deterministically in Levels 0–3 and invoking `EscalationRouter` only on the 60 genuine `REVIEW` cases (`p = 0.20`), `FringeheadC_Hybrid` reduced expected governance cost from **26.00 units** (`BaselineB_AlwaysOnEvaluator`, $p = 1.00$) to **6.00 units** while maintaining a sub-millisecond p50 latency of **0.5782 ms** (vs **26.37 ms** in fast test mode for `BaselineB`).
- **Cryptographic Audit & RBAC Immutability Guarantees (`20 / 20` Passed):** All 10 operator attempts to weaken Level 0/1 rules and all 5 under-quorum proposals were deterministically rejected, while all 5 multi-signature amendments incremented policy versions (`1.0.0 -> 1.0.5`) and immediately pinpointed simulated historical ledger tampering via `verify_chain()`.
